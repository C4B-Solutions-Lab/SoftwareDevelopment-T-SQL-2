-- =============================================================================================================================================================================================================================
-- author:				�ukasz D�browski
-- project:				DABROWSKI SOFTWARE DEVELOPMENT
-- www:					https://github.com/Dabrowski-Software-Development?tab=repositories
-- creation date:		2016-10-12
-- modification date:	n/a
-- description:		    Converts JSON collection to a table. Support for SQL SERVER versions prior to SQL SERVER 2016.
--						End user is responsible for providing unique temporary table in the server context, bacause there is no unique solution to pick up the correct table
--						in case multiple sessions would create temp tables with the same name (SQL SERVER temp tables nature) in the same relatively short period of time.
--						"null" values in JSON object are converted to ___NULL___ literal. It is end-user responsibility to handle this value appropriately.
--						Date & time values are handled as in T-SQL, datetime value have to be separated with uppercase T letter, i.e. "2016-05-14T22:29:34"
--						This procedure depends on the following functions, which are included in this solution in the file called UTILS.sql
--													dbo.SUBSTRING2,
--													dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE,
--													dbo.TRY_REPLACE,
--													dbo.CHECK_TRY_REPLACE_RESULT,
--													dbo.GET_TRY_REPLACE_RESULT_STRING,
--													dbo.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED
--	
--			            Due to implementation details of handling null values [___NULL___] columns of type CHAR, NCHAR, VARCHAR and NVARCHAR that have null values in JSON object have to have column size of at least 10 characters.	
--						This version recognizes collection of complex JSON objects, where each item can be valid JSON object of ANY STRUCTURE.
--						Level of nested JSON objects is unlimited. Example of complex JSON objects is given below:
--
/*
									[{
										"property_one": "1",
										"property_two": "o1_A",
										"complex_subObject_level_one": {
																			"property_one": "11",
																			"property_two": "111",
																			"property_three": "THIS",
																			"property_four": "1001",
																			"complex_subObject_level_two": {
																											 "property_one": "a",
																											 "property_two": "b",
																											 "property_three": "a+b",
																											 "complex_subObject_level_three": {
																																				"property_one": "sss_1",
																																				"property_two": "sss_2",
																																				"property_three": "sss_3"
																											},
																											"property_four": "a+b+1"
																		},
																											"property_five": "#",
																											"property_six": "$",
																											"property_seven": "*"
										},
										"property_three": "3",
										"property_four": "4",
										"property_five": "5",
										"2_complex_subObject_level_one": {
																			"property_one": "61",
																			"property_two": "62",
																			"property_three": "sss_3_sub_obj6",
																			"property_four": "64",
																			"property_five": "#6",
																			"property_six": "$6",
																			"property_seven": "*6"
										},
										"complex_subObject_level_one_3": {
																			"property_one": "71",
																			"property_two": "72",
																			"property_three": "sss_3_sub_obj6>",
																			"property_four": "74",
																			"2_complex_subObject_level_two": {
																												"property_one": "a7",
																												"property_two": "b7",
																												"property_three": "a7+b7",
																												"2_complex_subObject_level_three": {
																																					"property_one": "7sss_1",
																																					"property_two": "7sss_2",
																																					"property_three": "7sss_3"
																												},
																												"property_four": "a+b+1+7"
																			},
																			"property_five": "#7",
																			"property_six": "$7",
																			"property_seven": "*7"
										},
										"4_complex_subObject_level_one": {
																			"property_one": "81",
																			"property_two": "82",
																			"property_three": "sss_3_sub_obj6>8",
																			"property_four": "84",
																			"complex_subObject_level_three_3": {
																												"property_one": "a8",
																												"property_two": "b8",
																												"property_three": "a8+b8",
																												"property_four": "a+b+1+8"
																			},
																			"property_five": "#8",
																			"property_six": "$8",
																			"property_seven": "*8"
										}
									}]
*/
--
-- INPUT PARAMETERS:
--					@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT 
--																	-> Names of tables in ASC order for each level respectively (names ONLY). Below is a table definition pseudocode i.e.
--																	   Based on the example provided in this solution configuration for this parameter is given below:
/*
										 #MY_ROOT_TABLE,
										 #MY_SUB_TABLE,#MY_SUB_SUB_TABLE,#MY_SUB_SUB_SUB_TABLE,
										 |,
										 #2_MY_SUB_TABLE,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___,
										 |,
										 #3_MY_SUB_TABLE,#3_MY_SUB_SUB_TABLE,#3_MY_SUB_SUB_SUB_TABLE,
										 |,
										 #4_MY_SUB_TABLE,#4_MY_SUB_SUB_TABLE,___MISSING_LEVEL_OBJECT___

*/
--						Explanation:
/*
								#MY_ROOT_TABLE - root table containing top level JSON object's properties

								#MY_SUB_TABLE,#MY_SUB_SUB_TABLE,#MY_SUB_SUB_SUB_TABLE - comma separated tables containing FIRST complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								| - reserved character that acts as a separator among multiple complex child JSON objects
								
								#2_MY_SUB_TABLE,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___ - comma separated tables containing SECOND complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								#3_MY_SUB_TABLE,#3_MY_SUB_SUB_TABLE,#3_MY_SUB_SUB_SUB_TABLE - comma separated tables containing THIRD complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								#4_MY_SUB_TABLE,#4_MY_SUB_SUB_TABLE,___MISSING_LEVEL_OBJECT___ - comma separated tables containing FOURTH complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								___MISSING_LEVEL_OBJECT___ - reserved literal telling that current complex child JSON object is missing particular nesting level's data
*/ 
--					@P_JSON_COLLECTION
--									-> Collection of complex JSON objects
--
--                  THIS VERSION DOES NOT recognize nesting collection ( [...] ) of JSON objects inside a single object YET.
--                  This version IS THE REPLACEMENT of CONVERT_JSON_OBJECT_TO_SQL_TABLE_2 procedure. It is built upon that procedure WITH SEVERAL OPTIMIZATIONS.
--
--				 _______________________________________________________________________________________________________________________________________________________________
--				|																																						        |
--				|	IN SHORT, THIS VERSION IS A "UNION ALL" OF CONVERT_JSON_OBJECT_TO_SQL_TABLE && CONVERT_JSON_OBJECT_TO_SQL_TABLE_2 with addition of allowing multiple        |
--				|	complex objects being children of parent object, i.e. collection of complex any-structured JSON objects with each complex JSON object being the same size.	|																							 |		
--				|_______________________________________________________________________________________________________________________________________________________________|
--
--
-- WARNING:			
--					
--					IF @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT HAS CONFIGURATION LIKE BELOW:

/*
										 #MY_ROOT_TABLE,
										 #MY_SUB_TABLE,#MY_SUB_SUB_TABLE,#MY_SUB_SUB_SUB_TABLE,___MISSING_LEVEL_OBJECT___,
										 |,
										 #2_MY_SUB_TABLE,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___
										 |,
										 #3_MY_SUB_TABLE,#3_MY_SUB_SUB_TABLE,#3_MY_SUB_SUB_SUB_TABLE,___MISSING_LEVEL_OBJECT___
										 |,
										 #4_MY_SUB_TABLE,#4_MY_SUB_SUB_TABLE,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___


					THEN THERE IS CLEAR THAT JSON COLLECTION HAS ONLY 3 NESTED LEVELS STARTING FROM ROOT LEVEL AND 4TH NESTED LEVEL DOES NOT EXIST IN ANY COMPLEX OBJECT,
					THEN ALGORITHM WILL RUN INDEFINITELY. THERE IS NO SUCH CHECKING DUE TO PERFORMANCE ISSUE.
					CONFIGURATION HAS TO MATCH THE STRUCTURE OF JSON MAIN OBJECT IN THE COLLECTION.

*/
--
--					THERE IS ONE LIMITATION AS FOR THIS ALGORITHM: collection of complex any-structured JSON objects with any complex JSON object being of different size is NOT ALLOWED.
--																   ALLOWING FOR THE ABOVE IS PUT INTO CONSIDERATION!
--                  
-- EXAMPLE USAGE:   please refer to testing.txt file provided with this solution for further details.
--
--					In order to join tables provided as comma separated string (to get one row for each JSON object),
--					there is a requiremment to join all these tables with _TABLE_INTERNAL_PK_ column, which is generated internally.
--					Therefore this column name _TABLE_INTERNAL_PK_ is a reserved one and any table provided as comma separated string cannot contain column with such name.
--					First table containing such column name will raise an error.
--
--					This version includes property names validation (duplicate names detection) per deepest complex object, i.e. every complex object on given nesting level has to have unique property names.
--					First example below passes validation:
/*
								"complex_subObject_level_one": {
									"property_one": "11",
									"property_two": "111",
									"property_three": "THIS",
									"property_four": "1001",
									"1_complex_subObject_level_two": {
										"property_one": "a",
										"property_two": "b",
										"property_three": "a+b",
										"property_four": "a+b+1",
										"1_complex_subObject_level_three": {
											"property_one": "sss_1",
											"property_two": "sss_2",
											"property_three": "sss_3"
										}
									},
									"property_five": "#",
									"property_six": "$",
									"property_seven": "*"
								}

					whereas second example does not:

								"complex_subObject_level_one": {
									"property_one": "11",
									"property_two": "111",
									"property_three": "THIS",
									"property_four": "1001",
									"1_complex_subObject_level_two": {
										"property_one": "a",
										"property_two": "b",
										"property_three": "a+b",
										"property_four": "a+b+1",
										"1_complex_subObject_level_three": {
											"property_one": "sss_1",
											"property_two": "sss_2",
											"property_three": "sss_3"
										}
									},
									"property_five": "#",
									"property_one": "$",     <---  duplicated name detected
									"property_seven": "*"
								}
*/ 
--					
-- version:			1.5.0
-- changes:
--
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		lukkasz.dabrowski@gmail.com
-- =============================================================================================================================================================================================================================
IF OBJECT_ID ('CONVERT_JSON_OBJECT_TO_SQL_TABLE_3') IS NOT NULL
 DROP PROC CONVERT_JSON_OBJECT_TO_SQL_TABLE_3
GO


CREATE PROCEDURE CONVERT_JSON_OBJECT_TO_SQL_TABLE_3
(
 @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT AS NVARCHAR(MAX),
 @P_JSON_COLLECTION AS NVARCHAR(MAX)
)
AS
BEGIN
	   SET NOCOUNT ON

	   DECLARE
		@ERROR_TEMPLATE AS NVARCHAR(MAX) = '',
		@ERROR_MESSAGE AS NVARCHAR(MAX) = '',
		@SEPARATOR AS CHAR(1) = '|',
		@MISSING_LEVEL_OBJECT AS CHAR(26) = '___MISSING_LEVEL_OBJECT___',
		@EMPTY_STRING AS VARCHAR(1) = '',
		@TABULATOR AS CHAR(1) = CHAR(9),
		@ENTER AS CHAR(2) = CHAR(13)+CHAR(10),
		@JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX AS INT = -1,
		@JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX AS INT = -1,
		@JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS INT = 0,
		@JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX AS INT = -1, /* @SEPARATOR AS CHAR(1) = '|' */
		@BREAK_LOOP AS BIT = 0


		--VALIDATE JSON COLLECTION
		DECLARE @JSON_COLLECTION AS NVARCHAR(MAX) = REPLACE(REPLACE(LTRIM(RTRIM(@P_JSON_COLLECTION)), @ENTER, ''), @TABULATOR, @EMPTY_STRING)
		DECLARE @JSON_COLLECTION_LENGTH AS INT = LEN(@JSON_COLLECTION)
		DECLARE @COMMA AS CHAR(1) = ','
		DECLARE @COLON AS CHAR(1) = ':'
		DECLARE @QUOTATION AS CHAR(1) = '"'
		DECLARE @OPENING_CURLY_BRACE AS CHAR(1) = '{'
		DECLARE @CLOSING_CURLY_BRACE AS CHAR(1) = '}'
		DECLARE @JSON_PROPERTY_NULL_VALUE AS CHAR(4) = 'null'
		DECLARE @NULL_CONSTANT AS CHAR(10) = '___NULL___'
		DECLARE @UNKNOWN AS NVARCHAR(13) = '___UNKNOWN___'


		DECLARE @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET AS BIT = 0
		
		IF ((@JSON_COLLECTION_LENGTH - LEN(REPLACE(REPLACE(@JSON_COLLECTION, @OPENING_CURLY_BRACE, @EMPTY_STRING), @CLOSING_CURLY_BRACE, @EMPTY_STRING))) / LEN(@COMMA)) % 2 = 0
		 SET @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET = 1

	    IF @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET = 0
		 BEGIN
			SET @ERROR_TEMPLATE = 'JSON collection does not represent valid JSON. Number of opening and closing curly brackets mismatch.'
			SET @ERROR_MESSAGE = ''
	   		RAISERROR (
						@ERROR_TEMPLATE,
						16,
						1,
						@ERROR_TEMPLATE,
						N''
					  )
			 RETURN
		 END

		--REMOVE SPECIAL CHARACTERS FROM INPUT PARAMETER (\t, space, [enter])
		SET @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT = LTRIM(RTRIM(REPLACE(REPLACE(@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT, @TABULATOR, @EMPTY_STRING), @ENTER, @EMPTY_STRING)))

		--ADD NECESSARY COMMA TO THE END OF TABLES' NAMES IF OMITTED
		IF RIGHT(@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT, 1) <> ','
		 SET @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT = @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT + ','

		--CREATE TEMP TABLE TO STORE TABLES' NAMES THAT WILL HOLD JSON DATA
		CREATE TABLE #JSON_TABLE_COLLECTION
		(
			ID INT,
			TABLE_NAME SYSNAME
		)
		
		INSERT #JSON_TABLE_COLLECTION
		SELECT
			CT.ID,
			CT.CUSTOM_COLUMN AS TABLE_NAME
		FROM DBO.CREATE_CUSTOM_TABLE(@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT, DEFAULT, DEFAULT, DEFAULT, DEFAULT) AS CT

		--REMOVE TABULATORS && ENTERS FROM TABLE NAMES
		UPDATE JTC
			SET JTC.TABLE_NAME = LTRIM(RTRIM(REPLACE(REPLACE(JTC.TABLE_NAME, @TABULATOR, @EMPTY_STRING), @ENTER, @EMPTY_STRING)))
		FROM #JSON_TABLE_COLLECTION AS JTC



		--VALIDATE TABLES NAMES
		DECLARE
			@VALIDATION_INDEX_START AS INT = 1,
			@VALIDATION_INDEX_END AS INT = -1,
			@TABLE_NAME AS SYSNAME = ''

		SELECT @VALIDATION_INDEX_END = MAX(JTC.ID) FROM #JSON_TABLE_COLLECTION AS JTC

		WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
		 BEGIN
			SELECT
				@TABLE_NAME = JTC.TABLE_NAME
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @VALIDATION_INDEX_START
			
			IF @TABLE_NAME <> @SEPARATOR AND @TABLE_NAME <> @MISSING_LEVEL_OBJECT AND NOT EXISTS (
				SELECT 1/0
				FROM tempdb.INFORMATION_SCHEMA.TABLES AS T
				WHERE T.TABLE_NAME LIKE @TABLE_NAME + '%'
			)
			  BEGIN
				SET @ERROR_TEMPLATE = 'Temporary table ' + CAST(@TABLE_NAME AS VARCHAR(MAX)) + ' does not exist.'
				SET @ERROR_MESSAGE = ''
	   			RAISERROR (
							@ERROR_TEMPLATE,
							16,
							1,
							@ERROR_TEMPLATE,
							N''
						  )
				BREAK;
			  END

			SET @TABLE_NAME = ''
			SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
		 END
	 
		--RESET @VALIDATION_INDEX_START TO 1
		SET @VALIDATION_INDEX_START = 1



		--ADD TWO COLUMNS TO STORE [INSERT SELECT TEMPLATE] && [INSERT SELECT DATA ROW] FOR EACH TABLE
		ALTER TABLE #JSON_TABLE_COLLECTION ADD INSERT_SELECT_TEMPLATE_HEADER NVARCHAR(MAX) DEFAULT N''
		ALTER TABLE #JSON_TABLE_COLLECTION ADD INSERT_SELECT_DATA_ROW NVARCHAR(MAX) DEFAULT N''

		--CREATE INSERT SELECT TEMPLATE
		DECLARE 
			@MIN_ORDINAL_POSITION AS INT = 1,
			@MIN_ORDINAL_POSITION_TO_STRING AS VARCHAR(MAX) = '',
			@MAX_ORDINAL_POSITION AS INT = -1,
			@COLUMN_NAME AS SYSNAME = '',
			@DATA_TYPE AS SYSNAME = '',
			@COLUMN_FULL_TYPE AS SYSNAME = '',
			@DYNAMIC_INSERT_QUERY AS NVARCHAR(MAX) = '',
			@SYSTEM_TYPE_ID AS TINYINT,
			@MAX_LENGTH AS SMALLINT,
			@PRECISION AS TINYINT,
			@SCALE AS TINYINT,

			@JSON_OBJECT_LAST_PROPERTY_ID AS INT = -1,
			@JSON_DATA_FIRST_ROW AS INT = 1,
			@JSON_DATA_FIRST_ROW_TO_STRING AS VARCHAR(MAX) = '',
			@JSON_DATA_LAST_ROW AS INT = -1,
			@INSERT_QUERY AS NVARCHAR(MAX) = '',
			@PROPERTY_VALUE AS NVARCHAR(MAX) = '',
			@DO_REPLACEMENT_WITH_DIVISION AS INT = 0,
			@UNION_ALL AS SYSNAME = ' UNION ALL ',
			@PK_INTERNAL_TABLE_NAME_PLACEHOLDER AS CHAR(18) = '{__________x_%^$}',
			@_TABLE_NAME_PK_INTERNAL_ AS CHAR(19) = '_TABLE_INTERNAL_PK_'

		DECLARE
			@ADD_INTERNAL_PRIVATE_KEY_TEMPLATE AS NVARCHAR(MAX) = 'ALTER TABLE ' + @PK_INTERNAL_TABLE_NAME_PLACEHOLDER + ' ADD ' + @_TABLE_NAME_PK_INTERNAL_ + ' INT IDENTITY',
			@ADD_INTERNAL_PRIVATE_KEY AS NVARCHAR(MAX) = ''


		WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
		 BEGIN
			SELECT
				@TABLE_NAME = JTC.TABLE_NAME
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @VALIDATION_INDEX_START

			IF @TABLE_NAME = @SEPARATOR OR @TABLE_NAME = @MISSING_LEVEL_OBJECT
			 BEGIN
				SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
				CONTINUE
			 END

			SELECT 
				T.ORDINAL_POSITION,
				T.COLUMN_NAME,
				T.DATA_TYPE
			INTO #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE
			FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS T
			WHERE T.TABLE_NAME LIKE @TABLE_NAME + '%'

			IF EXISTS (
				SELECT 1/0 
				FROM #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE
				WHERE COLUMN_NAME = @_TABLE_NAME_PK_INTERNAL_
			)
			 BEGIN
				SET @ERROR_TEMPLATE = 'Table ' + @TABLE_NAME +  ' contains column ' + @_TABLE_NAME_PK_INTERNAL_ + ', which is a reserved column name due to implementation details and cannot exist with such name in this table.' + @ENTER +
									  'Change column name.'
				RAISERROR (
							@ERROR_TEMPLATE,
							16,
							1,
							@ERROR_TEMPLATE,
							N''
						  )
				BREAK
			 END

			SELECT
				@MAX_ORDINAL_POSITION = MAX(EUTBOTT.ORDINAL_POSITION)
			FROM #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE AS EUTBOTT
			SET @DYNAMIC_INSERT_QUERY = ' SELECT '


			--CREATE SELECT STATEMENT CONSISTING OF ALL THE COLUMNS IN THE TABLE
			WHILE @MIN_ORDINAL_POSITION <= @MAX_ORDINAL_POSITION
			 BEGIN
				SELECT
					@COLUMN_NAME = EUT.COLUMN_NAME,
					@DATA_TYPE = EUT.DATA_TYPE
				FROM #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE AS EUT
				WHERE EUT.ORDINAL_POSITION = @MIN_ORDINAL_POSITION

				SET @COLUMN_FULL_TYPE =  dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE(@COLUMN_NAME, @DATA_TYPE, @TABLE_NAME, 1)

				SET @MIN_ORDINAL_POSITION_TO_STRING = CAST(@MIN_ORDINAL_POSITION AS VARCHAR(MAX))
				SET @DYNAMIC_INSERT_QUERY = @DYNAMIC_INSERT_QUERY + 'CAST({_________________$' + @MIN_ORDINAL_POSITION_TO_STRING + '} AS ' + @COLUMN_FULL_TYPE + '), '

				SET @MIN_ORDINAL_POSITION = @MIN_ORDINAL_POSITION + 1
			 END
		 
			SET @DYNAMIC_INSERT_QUERY = RTRIM(@DYNAMIC_INSERT_QUERY)

			SET @DYNAMIC_INSERT_QUERY = LEFT(@DYNAMIC_INSERT_QUERY, LEN(@DYNAMIC_INSERT_QUERY) - 1)

			--UPDATE CURRENT TABLE'S INSERT SELECT TEMPLATE
			UPDATE JTC
			 SET
				JTC.INSERT_SELECT_TEMPLATE_HEADER = @DYNAMIC_INSERT_QUERY,
				JTC.INSERT_SELECT_DATA_ROW = @DYNAMIC_INSERT_QUERY
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @VALIDATION_INDEX_START
			
			--ADD IDENTITY COLUMN TO TABLE
			SET @ADD_INTERNAL_PRIVATE_KEY = REPLACE(@ADD_INTERNAL_PRIVATE_KEY_TEMPLATE, @PK_INTERNAL_TABLE_NAME_PLACEHOLDER, @TABLE_NAME)
			EXEC (@ADD_INTERNAL_PRIVATE_KEY)
			SET @ADD_INTERNAL_PRIVATE_KEY = ''

			--RESET NECESSARY VARIABLES TO DEFAULT VALUES
			SET @MIN_ORDINAL_POSITION = 1
			SET @MAX_ORDINAL_POSITION = -1
			SET @DYNAMIC_INSERT_QUERY = ''
			
			DROP TABLE #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE

			SET @TABLE_NAME = ''
			SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
		 END


		/* REMOVE FIRST OPENING AND LAST CLOSING SQUARE BRACKET */
		SET @JSON_COLLECTION = RIGHT(@JSON_COLLECTION, LEN(@JSON_COLLECTION) - 1)
		SET @JSON_COLLECTION = LEFT(@JSON_COLLECTION, LEN(@JSON_COLLECTION) - 1)
		SET @JSON_COLLECTION = LTRIM(RTRIM(@JSON_COLLECTION)) + @COMMA

		
		/* INSERT EACH OBJECT INTO TABLE */
		CREATE TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL(ID INT, JSON_ITEM NVARCHAR(MAX))
		INSERT #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
		SELECT
			JT.ID,
			JT.CUSTOM_COLUMN 
		FROM dbo.CREATE_CUSTOM_TABLE(@JSON_COLLECTION, DEFAULT, DEFAULT, DEFAULT, DEFAULT) AS JT



		/* CONVERT JSON COLLECTION TO ORDERED TABLE ROW REPRESENTATION (PROPERTY, VALUE, OBJECT NUMBER, NESTING LEVEL, OBJECT PROPERTY INDEX) [ CORE PROCESSING - PART 1 ] */
		ALTER TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL ADD PROPERTY_NAME NVARCHAR(MAX), PROPERTY_VALUE NVARCHAR(MAX), NESTING_LEVEL BIGINT, OBJECT_NUMBER BIGINT

		DECLARE
		 @INDEX_START_POSITION AS INT = 1,
		 @INDEX_END_POSITION AS INT = -1,
		 @JSON_OBJECT_HEIGHT AS INT = -1,
	 	 @NESTING_LEVEL AS INT = 1,
		 @CURRENT_TRAVERSED_ITEM AS NVARCHAR(MAX)= '',
		 @CURRENT_TRAVERSED_ITEM_ENDING_CURLY_BRACKETS AS NVARCHAR(MAX)= ''

		SET @JSON_OBJECT_HEIGHT = (
									SELECT
										(SELECT COUNT_BIG(*) FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL)  / COUNT_BIG(*) AS JSON_OBJECT_HEIGHT
									FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL WHERE LEFT(LTRIM(JSON_ITEM), 1) = '{'
								  )
		SELECT @INDEX_END_POSITION = MAX(ID) FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL


		WHILE @INDEX_START_POSITION <= @INDEX_END_POSITION
		BEGIN
			SELECT
				@CURRENT_TRAVERSED_ITEM = LTRIM(RTRIM(REPLACE(REPLACE(JSON_ITEM, @TABULATOR, ''), @ENTER, '')))
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
			WHERE ID = @INDEX_START_POSITION

			IF @INDEX_START_POSITION = 1 OR @INDEX_START_POSITION % @JSON_OBJECT_HEIGHT = 1 --FIRST PROPERTY OF NEXT (NOW CURRENT) OBJECT WAS PROCESSED, SO CUT OUT FIRST OPENING CURLY BRACE
			 SET @CURRENT_TRAVERSED_ITEM = SUBSTRING(@CURRENT_TRAVERSED_ITEM, 2, LEN(@CURRENT_TRAVERSED_ITEM))
			ELSE IF @INDEX_START_POSITION % @JSON_OBJECT_HEIGHT = 0 --LAST PROPERTY OF CURRENT OBJECT WAS PROCESSED, SO RESET NESTING LEVEL TO INITIAL VALUE: 1
			 BEGIN
				SET @CURRENT_TRAVERSED_ITEM = DBO.SUBSTRING2(@CURRENT_TRAVERSED_ITEM, LEN(@CURRENT_TRAVERSED_ITEM), LEN(@CURRENT_TRAVERSED_ITEM)-1, 1)
			 END

			IF CHARINDEX('{', @CURRENT_TRAVERSED_ITEM) = 0 -- CURRENT NESTING LEVEL'S PROPERTY:VALUE PAIR
			  BEGIN
			    UPDATE JICTTI
					SET
						JICTTI.PROPERTY_NAME = SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM) + 1, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM) - 3),
						JICTTI.PROPERTY_VALUE = 
												NULLIF(SUBSTRING(
																 @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3,
																 CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3) - CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0)-3
																)
													   ,
													   @JSON_PROPERTY_NULL_VALUE
													  ),
						JICTTI.NESTING_LEVEL = @NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
				WHERE JICTTI.ID = @INDEX_START_POSITION

				--CHECK IF CURRENT NESTING LEVEL'S PROPERTY:VALUE PAIR IS LAST ONE AT THIS LEVEL. IF SO DECREASE NESTING LEVEL BY 1
				IF CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0
				 SET @NESTING_LEVEL = @NESTING_LEVEL - LEN(LTRIM(RTRIM(DBO.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED(@CURRENT_TRAVERSED_ITEM, '}]'))))

			  END
			ELSE IF CHARINDEX('{', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0 -- CURRENT NESTING LEVEL'S NESTED OBJECT -> CURRENT NESTING LEVEL ++
			 BEGIN
			  SET @NESTING_LEVEL = @NESTING_LEVEL + 1
			  SET @CURRENT_TRAVERSED_ITEM = LTRIM(RTRIM(SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX('{', @CURRENT_TRAVERSED_ITEM)+1, LEN(@CURRENT_TRAVERSED_ITEM))))
			    UPDATE JICTTI
					SET
						JICTTI.PROPERTY_NAME = SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM) + 1, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM) - 3),
						JICTTI.PROPERTY_VALUE = 
												NULLIF(SUBSTRING(
																 @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3,
																 CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3) - CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0)-3
																)
													   ,
													   @JSON_PROPERTY_NULL_VALUE
													  ),
						JICTTI.NESTING_LEVEL = @NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
				WHERE JICTTI.ID = @INDEX_START_POSITION
			 END
			ELSE IF CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0 -- CURRENT NESTING LEVEL'S OBJECT LAST PROPERTY:VALUE PAIR-> CURRENT NESTING LEVEL --
			 BEGIN
			  SET @NESTING_LEVEL = @NESTING_LEVEL - 1
			  SET @CURRENT_TRAVERSED_ITEM_ENDING_CURLY_BRACKETS = LTRIM(RTRIM(SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX('}', @CURRENT_TRAVERSED_ITEM)+1, LEN(@CURRENT_TRAVERSED_ITEM))))
			  SET @CURRENT_TRAVERSED_ITEM = LTRIM(RTRIM(SUBSTRING(@CURRENT_TRAVERSED_ITEM, 1, CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM)))-1)))
			    UPDATE JICTTI
					SET
						JICTTI.PROPERTY_NAME = SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM) + 1, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM) - 3),
						JICTTI.PROPERTY_VALUE = 
												NULLIF(SUBSTRING(
																 @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3,
																 CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3) - CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0)-3
																)
													   ,
													   @JSON_PROPERTY_NULL_VALUE
													  ),
						JICTTI.NESTING_LEVEL = @NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
				WHERE JICTTI.ID = @INDEX_START_POSITION

				IF CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0
				 SET @NESTING_LEVEL = @NESTING_LEVEL - LEN(LTRIM(RTRIM(DBO.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED(@CURRENT_TRAVERSED_ITEM, '}]'))))

			 END

			--UPDATE WHICH PROPERTY'S OBJECT NUMBER WE ARE DEALING WITH
			UPDATE JICTTI
			 SET
				JICTTI.OBJECT_NUMBER = CASE WHEN ID % @JSON_OBJECT_HEIGHT = 0 THEN ID / @JSON_OBJECT_HEIGHT ELSE ID / @JSON_OBJECT_HEIGHT + 1 END
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
			WHERE JICTTI.ID = @INDEX_START_POSITION

			SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
		END




		/* ORDER COLLECTION BY THE WAY IT IS PROVIDED TO THIS PROCEDURE (first object's first property, second property, etc...) [ CORE PROCESSING - PART 2 ] */
		SELECT
			JICTTI.*,
			ROW_NUMBER() OVER(PARTITION BY JICTTI.OBJECT_NUMBER, JICTTI.NESTING_LEVEL ORDER BY JICTTI.ID) AS CURRENT_OBJECT_PROPERTY_INDEX
		INTO #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2_TEMP
		FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI

		SELECT
			JICTTI.*,
			ROW_NUMBER() OVER(ORDER BY (SELECT 0)) AS TEMP_ID_INTERNAL
		INTO #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2
		FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2_TEMP AS JICTTI

		/* UPDATE ID OVER WHICH THE WHOLE COLLECTION IS PROCESSED */
		UPDATE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2
		 SET
			ID = TEMP_ID_INTERNAL,
			TEMP_ID_INTERNAL = ID
		
		/* REMOVE TEMPORARY INTERNAL ID */
		ALTER TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 DROP COLUMN TEMP_ID_INTERNAL


		/* PROPERTY NAMES VALIDATION (each nesting level has to have unique property names in the context of nearest complex object. Check http://jsonlint.com/ [JSONLint - The JSON Validator]) [ CORE PROCESSING - PART 3 ] */
		DECLARE
			@CURRENT_LEVEL AS INT = 1, --THIS INDICATES CURRENT PROCESSED LEVEL
			@LAST_LEVEL AS INT = -1, --THIS INDICATES DEEPEST NESTING LEVEL IN A SINGLE MAIN OBJECT BY DESIGN. ANY OBJECT EITHER HAS ACTUAL DATA FOR EACH NESTING LEVEL OR MARKS SUCH MISSING LEVEL WITH ___MISSING_LEVEL_OBJECT___
			@NUMBER_OF_PROPS_PER_NESTING_LEVEL AS INT = -1,
			@NUMBER_OF_UNIQUE_PROP_NAMES_PER_NESTING_LEVEL AS INT = -1,
			@OBJ_NUMBER AS BIGINT = -1, --THIS INDICATES ONE-BASED INDEX OF MAIN COMPLEX OBJECT IN THE WHOLE COLLECTION,
			@COMPLEX_PROPERTY_FOR_CURRENT_LEVEL_WAS_FOUND AS BIT = 0,
			@CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT AS INT  = 0,
			@FIND_COMPLEX_PROPERTY_START AS INT = -1,
			@FIND_COMPLEX_PROPERTY_STOP AS INT  = -1,
			@REQUIRED_MIN_NUMBER_OF_INTERATIONS AS INT = -1,
			@NUMBER_OF_FOUND_MISSING_LEVEL_OBJECTS AS INT = 0

		SELECT
			@LAST_LEVEL = MIN(JTC.ID) - 1
		FROM #JSON_TABLE_COLLECTION AS JTC
		WHERE JTC.TABLE_NAME = @SEPARATOR

		CREATE TABLE #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL (NESTING_LEVEL INT, NUMBER_OF_PROPERTIES INT)
		INSERT #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL
		SELECT
			JTC.ID, MAX(ISNULL(ISC.ORDINAL_POSITION, 0)) - 1 
		FROM #JSON_TABLE_COLLECTION AS JTC
		LEFT JOIN tempdb.INFORMATION_SCHEMA.COLUMNS AS ISC ON ISC.TABLE_NAME LIKE JTC.TABLE_NAME + '%'
		GROUP BY JTC.ID

		--IN CASE FIRST MAIN COMPLEX OBJECT IS MISSING ANY NESTING LEVEL DATA, FIND NUMBER OF PROPERTIES FROM SUBSEQUENT COMPLEX OBJECTS FOR THOSE NESTING LEVELS
		IF EXISTS (
			SELECT 1/0
			FROM #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL AS NOPPNL
			WHERE NOPPNL.NESTING_LEVEL <= @LAST_LEVEL 
			 AND NOPPNL.NUMBER_OF_PROPERTIES = -1
		)
		BEGIN
			DECLARE
				@FIND_PROPS_NUMBER_INDEX_START AS INT = 2,
				@FIND_PROPS_NUMBER_INDEX_STOP AS INT = @LAST_LEVEL,
				@FOUND_NUMBER_OF_PROPERTIES AS INT = -1,
				@CURRENT_PROCESSED_NESTING_LEVEL AS INT = -1

			WHILE @FIND_PROPS_NUMBER_INDEX_START <= @FIND_PROPS_NUMBER_INDEX_STOP
			 BEGIN
				IF EXISTS (
					SELECT 1/0
					FROM #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL AS NOPPNL
					WHERE NOPPNL.NESTING_LEVEL = @FIND_PROPS_NUMBER_INDEX_START
					 AND NOPPNL.NUMBER_OF_PROPERTIES = -1
				)
				BEGIN
				 SET @CURRENT_PROCESSED_NESTING_LEVEL = @FIND_PROPS_NUMBER_INDEX_START

				 WHILE @FOUND_NUMBER_OF_PROPERTIES = -1
				  BEGIN
					 SET @CURRENT_PROCESSED_NESTING_LEVEL = @CURRENT_PROCESSED_NESTING_LEVEL + @LAST_LEVEL
					 
					 SELECT
						@FOUND_NUMBER_OF_PROPERTIES = NOPPNL.NUMBER_OF_PROPERTIES
					 FROM #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL AS NOPPNL
					 WHERE NOPPNL.NESTING_LEVEL = @CURRENT_PROCESSED_NESTING_LEVEL

					 IF @FOUND_NUMBER_OF_PROPERTIES <> -1
					  BEGIN
					   UPDATE NOPPNL
					    SET NOPPNL.NUMBER_OF_PROPERTIES = @FOUND_NUMBER_OF_PROPERTIES
					   FROM #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL AS NOPPNL
					   WHERE NOPPNL.NESTING_LEVEL = @FIND_PROPS_NUMBER_INDEX_START
					  END
				  END
				END			  
			   
			  SET @FOUND_NUMBER_OF_PROPERTIES = -1
			  SET @CURRENT_PROCESSED_NESTING_LEVEL = -1
			  SET @FIND_PROPS_NUMBER_INDEX_START = @FIND_PROPS_NUMBER_INDEX_START + 1
			 END
		END

		/* DELETE UNNECESSARY DATA */
		DELETE NOPPNL
		FROM #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL AS NOPPNL
		WHERE NOPPNL.NESTING_LEVEL > @LAST_LEVEL

		/* RESET @INDEX_START_POSITION TO 1 AND COUNT NUMBER OF COMPLEX OBJECTS PER MAIN OBJECT */
		SET @INDEX_START_POSITION = 1

		/* EXECUTE ACTUAL VALIDATION [ CORE PROCESSING - PART 4 ] */
		WHILE @INDEX_START_POSITION <= @INDEX_END_POSITION
		 BEGIN
		 --CALCULATE NUMBER OF PROPERTIES FOR NEXT LEVEL
		  SELECT
			@NUMBER_OF_PROPS_PER_NESTING_LEVEL = NOPPNL.NUMBER_OF_PROPERTIES
		  FROM #NUMBER_OF_PROPERTIES_PER_NESTING_LEVEL AS NOPPNL
		  WHERE NOPPNL.NESTING_LEVEL = @CURRENT_LEVEL

		  ;WITH PROPS_PER_NESTING_LEVEL(PROP_NAME, OBJ_NUMBER) AS (
			  SELECT
				TOP (@NUMBER_OF_PROPS_PER_NESTING_LEVEL) LTRIM(RTRIM(JICTTI2.PROPERTY_NAME)), JICTTI2.OBJECT_NUMBER
			  FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI2
			  WHERE JICTTI2.ID >= @INDEX_START_POSITION
			  ORDER BY JICTTI2.ID
		  )
		  SELECT
			@NUMBER_OF_UNIQUE_PROP_NAMES_PER_NESTING_LEVEL = COUNT(DISTINCT PPNL.PROP_NAME),
			@OBJ_NUMBER = MIN(PPNL.OBJ_NUMBER)
		  FROM PROPS_PER_NESTING_LEVEL AS PPNL

		  --SEEK CURRENT COMPLEX PROPERTY FOR CURRENT MAIN OBJECT (LEVEL 1 IS ROOT LEVEL)
		  IF @CURRENT_LEVEL > 1
		   BEGIN
		    SET @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT = @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT + 1
		   END

		  IF @NUMBER_OF_UNIQUE_PROP_NAMES_PER_NESTING_LEVEL <> @NUMBER_OF_PROPS_PER_NESTING_LEVEL
		   BEGIN
				SET @FIND_COMPLEX_PROPERTY_START = @CURRENT_LEVEL
				SELECT @FIND_COMPLEX_PROPERTY_STOP = 
												MAX(JTC.ID) + @LAST_LEVEL - 1
												FROM #JSON_TABLE_COLLECTION AS JTC
												WHERE JTC.TABLE_NAME = @SEPARATOR 
				
				SET @REQUIRED_MIN_NUMBER_OF_INTERATIONS = @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT
				
				IF @REQUIRED_MIN_NUMBER_OF_INTERATIONS = 1 AND (
															    SELECT CASE WHEN JTC.TABLE_NAME = @MISSING_LEVEL_OBJECT THEN 0 ELSE 1 END
																FROM #JSON_TABLE_COLLECTION AS JTC
																WHERE JTC.ID = @FIND_COMPLEX_PROPERTY_START
															   ) = 1 
				 BEGIN
					SET @REQUIRED_MIN_NUMBER_OF_INTERATIONS = 0
				 END

				WHILE @FIND_COMPLEX_PROPERTY_START <= @FIND_COMPLEX_PROPERTY_STOP
				 BEGIN
				  IF @REQUIRED_MIN_NUMBER_OF_INTERATIONS < 1
				   BEGIN
					  SELECT 
						@COMPLEX_PROPERTY_FOR_CURRENT_LEVEL_WAS_FOUND = CASE WHEN JTC.TABLE_NAME = @MISSING_LEVEL_OBJECT THEN 0 ELSE 1 END
					  FROM #JSON_TABLE_COLLECTION AS JTC
					  WHERE JTC.ID = @FIND_COMPLEX_PROPERTY_START

					  IF @COMPLEX_PROPERTY_FOR_CURRENT_LEVEL_WAS_FOUND = 1
					   BEGIN
						SET @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT = @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT + @NUMBER_OF_FOUND_MISSING_LEVEL_OBJECTS
						BREAK
					   END
					  ELSE
					   BEGIN
					    SET @NUMBER_OF_FOUND_MISSING_LEVEL_OBJECTS = @NUMBER_OF_FOUND_MISSING_LEVEL_OBJECTS + 1
					   END
				   END
				  ELSE
				   BEGIN
					  SELECT 
						@NUMBER_OF_FOUND_MISSING_LEVEL_OBJECTS = @NUMBER_OF_FOUND_MISSING_LEVEL_OBJECTS + CASE WHEN JTC.TABLE_NAME = @MISSING_LEVEL_OBJECT THEN 1 ELSE 0 END
					  FROM #JSON_TABLE_COLLECTION AS JTC
					  WHERE JTC.ID = @FIND_COMPLEX_PROPERTY_START					
				   END

				  SET @REQUIRED_MIN_NUMBER_OF_INTERATIONS = @REQUIRED_MIN_NUMBER_OF_INTERATIONS - 1
				  SET @FIND_COMPLEX_PROPERTY_START = @FIND_COMPLEX_PROPERTY_START + @LAST_LEVEL
				  
				  --IN CASE THERE ARE DUPLICATED PROPERTIES IN THE LAST COMPLEX PROPERTY FOR CURRENT NESTING LEVEL
				  IF @FIND_COMPLEX_PROPERTY_START > @FIND_COMPLEX_PROPERTY_STOP
				   SET @FIND_COMPLEX_PROPERTY_START = @FIND_COMPLEX_PROPERTY_START - @LAST_LEVEL

				 END
				
				IF @COMPLEX_PROPERTY_FOR_CURRENT_LEVEL_WAS_FOUND = 1
				 BEGIN
					SET @ERROR_TEMPLATE = 'JSON collection does not represent valid JSON.' + @ENTER +
										  'In the collection complex object with [one-based index = ' + CAST(@OBJ_NUMBER AS NVARCHAR(MAX))  +
										  ', complex property with one-based index = ' + CASE WHEN @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT = 0 AND @CURRENT_LEVEL = 1 THEN '0 (MAIN OBJECT)' ELSE CAST(@CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT AS NVARCHAR(MAX)) END +
										  ', nesting level with one-based index = ' + CAST(@CURRENT_LEVEL AS NVARCHAR(MAX)) + '] has duplicated property names.' + @ENTER +
										  'Property names have to be unique per property''s nearest parent object.'  
					SET @ERROR_MESSAGE = ''
	   				RAISERROR (
								@ERROR_TEMPLATE,
								16,
								1,
								@ERROR_TEMPLATE,
								N''
							  )
					 RETURN
				 END
				ELSE
				 BEGIN
					SET @ERROR_TEMPLATE = 'JSON collection does not represent valid JSON.' + @ENTER +
										  'In the collection complex object with [one-based index = ' + CAST(@OBJ_NUMBER AS NVARCHAR(MAX))  +
										  ', complex property with one-based index = ' + @UNKNOWN + 
										  ', nesting level with one-based index = ' + CAST(@CURRENT_LEVEL AS NVARCHAR(MAX)) + '] has duplicated property names.' + @ENTER +
										  'Property names have to be unique per property''s nearest parent object.'  
					SET @ERROR_MESSAGE = ''
	   				RAISERROR (
								@ERROR_TEMPLATE,
								16,
								1,
								@ERROR_TEMPLATE,
								N''
							  )
					 RETURN				  
				 END
		   END
          
		  --CHECK IF WE REACHED LAST NESTING LEVEL OF CURRENT MAIN JSON OBJECT
		  IF @INDEX_START_POSITION + @NUMBER_OF_PROPS_PER_NESTING_LEVEL = @OBJ_NUMBER * @JSON_OBJECT_HEIGHT
		   BEGIN
		    SET @CURRENT_LEVEL = 1
			SET @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT = 0
		   END
		  --CHECK IF [1. WE ARE ABOUT TO PROCESS NEXT NESTING LEVEL OF CURRENT MAIN JSON OBJECT] OR NEXT SET OF PROPERTY NAMES OF CURRENT NESTING LEVEL OF CURRENT MAIN JSON OBJECT
		  ELSE
		   BEGIN
		    --1.
		    IF(
				SELECT
					JICTTI2.NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI2
				WHERE JICTTI2.ID = @INDEX_START_POSITION + @NUMBER_OF_PROPS_PER_NESTING_LEVEL
			  ) <> @CURRENT_LEVEL
			  BEGIN
			    --SET CURRENT LEVEL TO NEXT LEVEL ...
				SET @CURRENT_LEVEL = @CURRENT_LEVEL + 1

				-- ... AND SUBSEQUENTLY WE ARE CHECKING IF WE ARE ABOUT TO PROCESS ANOTHER MAIN OBJECT
				IF @OBJ_NUMBER <> (
									SELECT JICTTI2.OBJECT_NUMBER
									FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI2 WHERE JICTTI2.ID = @INDEX_START_POSITION + @NUMBER_OF_PROPS_PER_NESTING_LEVEL
								  )
				BEGIN
				 SET @CURRENT_LEVEL = 1
				END


				--RESET THIS FLAG INDICATING THAT FOR CURRENT MAIN OBJECT FOR CURRENT LEVEL WE FOUND THE CORRECT COMPLEX PROPERTY
				SET @COMPLEX_PROPERTY_FOR_CURRENT_LEVEL_WAS_FOUND = 0

				--RESET CORRECT COMPLEX PROPERTY INDEX TO 0
				SET @CURRENT_INDEX_OF_COMPLEX_PROPERTY_IN_THE_PARENT_OBJECT = 0

				--RESET REQUIRED NUMBER OF MIN ITERATIONS
				SET @REQUIRED_MIN_NUMBER_OF_INTERATIONS = -1
			  END
		   END

		  SET @INDEX_START_POSITION = @INDEX_START_POSITION + @NUMBER_OF_PROPS_PER_NESTING_LEVEL
		 END


		/* FIND LAST INDEX OF COMPLEX PROPERTIES' SEPARATOR IN THE COLLECTION */
		SELECT
			@JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX = MAX(JTC.ID)
		FROM #JSON_TABLE_COLLECTION AS JTC
		WHERE JTC.TABLE_NAME = @SEPARATOR



		/* DISTRIBUTE EACH PROPERTY'S VALUE TO APPROPRIATE TABLE (1 MAIN JSON OBJECT <-> 1 TABLE RECORD) [ CORE PROCESSING - PART 5 ] */
		DECLARE
			@OBJECT_NUMBER AS INT = -1,
			@OBJECT_NUMBER_PREV AS INT = -1,
			@CURRENT_OBJECT_PROPERTY_INDEX AS INT = -1,
			@INSERT_SELECT_STATEMENT AS NVARCHAR(MAX) = N''

		SET @INDEX_START_POSITION = 1		
		SET @TABLE_NAME = ''
		SET @PROPERTY_VALUE = ''
		SET @NESTING_LEVEL = -1

		DECLARE 
			@LAST_PROCESSED_OBJECT_PROPERTY_INDEX AS INT = -1,
			@TRY_REPLACE_RESULT AS NVARCHAR(MAX) = N'',
			@OBJECT_COUNT AS INT  = 1,
			@MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY AS INT = 0,
			@CURRENT_LEVEL_OBJECT_PROPERTY_NEXT_MATCHING_TABLE_INDEX_START AS INT = 1,
			@CURRENT_LEVEL_OBJECT_PROPERTY_NEXT_MATCHING_TABLE_INDEX_STOP AS INT = 1

		WHILE @INDEX_START_POSITION <= @INDEX_END_POSITION
		 BEGIN
			--IF WE ARE PROCESSING LAST PROPERTY OF THE CURRENT OBJECT, PROCESS CURRENT OBJECT LAST PROPERTY (@INDEX_START_POSITION = @JSON_OBJECT_HEIGHT * @OBJECT_COUNT), THEN INSERT INTO CONNECTED TABLES OBJECT'S STATE
			IF @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> -1 AND @INDEX_START_POSITION = @JSON_OBJECT_HEIGHT * @OBJECT_COUNT AND @INDEX_START_POSITION <> @INDEX_END_POSITION --@OBJECT_NUMBER <> @OBJECT_NUMBER_PREV
			 BEGIN
				SELECT
					@PROPERTY_VALUE = ISNULL(JICTTI_2.PROPERTY_VALUE, @NULL_CONSTANT),
					@OBJECT_NUMBER = JICTTI_2.OBJECT_NUMBER,
					@NESTING_LEVEL = JICTTI_2.NESTING_LEVEL,
					@CURRENT_OBJECT_PROPERTY_INDEX = JICTTI_2.CURRENT_OBJECT_PROPERTY_INDEX
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI_2
				WHERE JICTTI_2.ID = @INDEX_START_POSITION
			   
				SELECT
					@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
				FROM #JSON_TABLE_COLLECTION AS JTC
				WHERE JTC.ID = @NESTING_LEVEL

				--CHECK IF WE ARE PROCESSING ANOTHER COMPLEX JSON OBJECT UNDER CURRENT PARENT OBJECT ( DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT) = 0 ), IN OTHER WORDS ANOTHER COMPLEX PROPERTY
				IF DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT) = 0
				 BEGIN
					SET @TRY_REPLACE_RESULT = N''
				    SET @BREAK_LOOP = 0
					WHILE @BREAK_LOOP = 0
					 BEGIN
					    --CALCULATE NUMBER OF COMPLEX SUBOBJECTS PER PARENT OBJECT
						SELECT TOP (1)
							@JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = JTC.ID - 1,
							@JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX = JTC.ID,
							@JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER + 1
						FROM #JSON_TABLE_COLLECTION AS JTC
						WHERE JTC.TABLE_NAME = @SEPARATOR
						 AND JTC.ID > @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX
						ORDER BY JTC.ID

						--IF WE PROCESS LAST COMPLEX SUBOBJECT OF PARENT OBJECT FOR CURRENT NESTING LEVEL IN THE COLLECTION
						IF @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX + 1 = @JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX
						 BEGIN
							SELECT
								@LAST_PROCESSED_OBJECT_PROPERTY_INDEX = MAX(C.ORDINAL_POSITION) - 1
							FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS C
							WHERE C.TABLE_NAME LIKE (SELECT JTC.TABLE_NAME 
													 FROM #JSON_TABLE_COLLECTION AS JTC
													 WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1) + '%'
						 END
						ELSE
						 BEGIN
							SELECT
								@LAST_PROCESSED_OBJECT_PROPERTY_INDEX = MAX(C.ORDINAL_POSITION) - 1
							FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS C
							WHERE C.TABLE_NAME LIKE (SELECT JTC.TABLE_NAME 
													 FROM #JSON_TABLE_COLLECTION AS JTC
													 WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX) + '%'
						 END
						
						--BELOW STEP IS PROCESSED IF CURRENT SUBOBJECT'S PROPERTY NESTING LEVEL IS F.E. 3 AND INDEX IS F.E. 9 AND WE KNOW THAT THIS NESTING LEVEL HAS 4 COLUMNS,
						-- AND SOME PREVIOUS SUBOBJECTS ARE MISSING SOME NESTING LEVELS, AND IN THIS CASE WE FOUND SUCH MISSING LEVEL ___MISSING_LEVEL_OBJECT___, => @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = NULL
						IF @LAST_PROCESSED_OBJECT_PROPERTY_INDEX IS NULL
						 BEGIN
						  SET @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY = @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY + 1
						  CONTINUE
						 END

						--CHECK IF THIS OBJECT'S CURRENT NESTING LEVEL HAS NO DATA FOR THE FIRST COMPLEX OBJECT'S CURRENT LEVEL IN THE COLLECTION
						IF NOT EXISTS (
						  SELECT 1/0
						  FROM #JSON_TABLE_COLLECTION AS JTC
						  WHERE JTC.ID = @NESTING_LEVEL
						   AND JTC.TABLE_NAME <> @MISSING_LEVEL_OBJECT
						) AND @CURRENT_OBJECT_PROPERTY_INDEX <= @LAST_PROCESSED_OBJECT_PROPERTY_INDEX
						BEGIN
						 SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER - 1
						END

						IF @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX + 1 = @JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX
						 BEGIN
						   IF @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY > 0
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX + @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY * @LAST_PROCESSED_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1
							END
						   ELSE
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1
							END
						 END
						ELSE
						 BEGIN
						   IF @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY > 0
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX + @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY * @LAST_PROCESSED_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX
							END
						   ELSE
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX
							END
						 END

						--CHECK IF WE FOUND ANOTHER COPLEX OBJECT
						SET @BREAK_LOOP = DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT)
						IF @BREAK_LOOP = 1
						 BEGIN
							UPDATE JTC
							 SET
								JTC.INSERT_SELECT_DATA_ROW = DBO.GET_TRY_REPLACE_RESULT_STRING(@TRY_REPLACE_RESULT)
							FROM #JSON_TABLE_COLLECTION AS JTC
							WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX

							BREAK
						 END
						ELSE
						 BEGIN
							IF NOT EXISTS (
							  SELECT 1/0
							  FROM #JSON_TABLE_COLLECTION AS JTC
							  WHERE JTC.ID = @NESTING_LEVEL
							   AND JTC.TABLE_NAME <> @MISSING_LEVEL_OBJECT
							)
							 BEGIN
								SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER - 1
							 END
						 END
						
						SET @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = -1
						SET @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = -1
						SET @TRY_REPLACE_RESULT = N''
					 END

					--WE PROCESSED CURRENT LEVEL PROPERTY OF ANOTHER COMPLEX OBJECT, THEREFORE RESET TEMPORARY VARIABLES TO DEFAULT VALUES
					SET @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = -1
					SET @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX = -1
					SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = 0
					SET @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY = 0
					SET @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = -1
					SET @TRY_REPLACE_RESULT = N''
				 END
				ELSE
				 BEGIN
					UPDATE JTC
					 SET
						JTC.INSERT_SELECT_DATA_ROW = DBO.GET_TRY_REPLACE_RESULT_STRING(@TRY_REPLACE_RESULT)
					FROM #JSON_TABLE_COLLECTION AS JTC
					WHERE JTC.ID = @NESTING_LEVEL
				 END
			
				SET @TRY_REPLACE_RESULT = N''				

				SET @VALIDATION_INDEX_START = 1
				WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
				 BEGIN
					SELECT
						@INSERT_SELECT_STATEMENT = 'INSERT ' + JTC.TABLE_NAME + ' ' + JTC.INSERT_SELECT_DATA_ROW
					FROM #JSON_TABLE_COLLECTION AS JTC
					WHERE JTC.ID = @VALIDATION_INDEX_START
					AND JTC.TABLE_NAME <> @SEPARATOR

					IF @INSERT_SELECT_STATEMENT <> N''
					 BEGIN
						EXEC (@INSERT_SELECT_STATEMENT)
						SET @INSERT_SELECT_STATEMENT = N''

						IF @VALIDATION_INDEX_START = @VALIDATION_INDEX_END
						 BEGIN
							UPDATE JTC
								SET
									JTC.INSERT_SELECT_DATA_ROW = JTC.INSERT_SELECT_TEMPLATE_HEADER
							FROM #JSON_TABLE_COLLECTION AS JTC
							WHERE JTC.ID = @VALIDATION_INDEX_START

							SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
							CONTINUE
						 END

						UPDATE JTC
						 SET
							JTC.INSERT_SELECT_DATA_ROW = JTC.INSERT_SELECT_TEMPLATE_HEADER
						FROM #JSON_TABLE_COLLECTION AS JTC
						WHERE JTC.ID = @VALIDATION_INDEX_START
					 END
					 
					 SET @INSERT_SELECT_STATEMENT = N''
					 SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
				 END
				 
				 SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
				 SET @OBJECT_COUNT = @OBJECT_COUNT + 1
			 END
			--WE'VE REACHED THE LAST PROPERTY OF THE LAST OBJECT IN THE COLLECTION
			ELSE IF @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> -1 AND @INDEX_START_POSITION = @INDEX_END_POSITION
			 BEGIN
				SELECT
					@PROPERTY_VALUE = ISNULL(JICTTI_2.PROPERTY_VALUE, @NULL_CONSTANT),
					@OBJECT_NUMBER = JICTTI_2.OBJECT_NUMBER,
					@NESTING_LEVEL = JICTTI_2.NESTING_LEVEL,
					@CURRENT_OBJECT_PROPERTY_INDEX = JICTTI_2.CURRENT_OBJECT_PROPERTY_INDEX
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI_2
				WHERE JICTTI_2.ID = @INDEX_START_POSITION
				
				SELECT
					@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
				FROM #JSON_TABLE_COLLECTION AS JTC
				WHERE JTC.ID = @NESTING_LEVEL

				--CHECK IF WE ARE PROCESSING ANOTHER COMPLEX JSON OBJECT UNDER CURRENT PARENT OBJECT ( DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT) = 0 ), IN OTHER WORDS ANOTHER COMPLEX PROPERTY
				IF DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT) = 0
				 BEGIN
					SET @TRY_REPLACE_RESULT = N''
				    SET @BREAK_LOOP = 0
					WHILE @BREAK_LOOP = 0
					 BEGIN
					    --CALCULATE NUMBER OF COMPLEX SUBOBJECTS PER PARENT OBJECT
						SELECT TOP (1)
							@JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = JTC.ID - 1,
							@JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX = JTC.ID,
							@JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER + 1
						FROM #JSON_TABLE_COLLECTION AS JTC
						WHERE JTC.TABLE_NAME = @SEPARATOR
						 AND JTC.ID > @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX
						ORDER BY JTC.ID

						--IF WE PROCESS LAST COMPLEX SUBOBJECT OF PARENT OBJECT FOR CURRENT NESTING LEVEL IN THE COLLECTION
						IF @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX + 1 = @JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX
						 BEGIN
							SELECT
								@LAST_PROCESSED_OBJECT_PROPERTY_INDEX = MAX(C.ORDINAL_POSITION) - 1
							FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS C
							WHERE C.TABLE_NAME LIKE (SELECT JTC.TABLE_NAME 
													 FROM #JSON_TABLE_COLLECTION AS JTC
													 WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1) + '%'
						 END
						ELSE
						 BEGIN
							SELECT
								@LAST_PROCESSED_OBJECT_PROPERTY_INDEX = MAX(C.ORDINAL_POSITION) - 1
							FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS C
							WHERE C.TABLE_NAME LIKE (SELECT JTC.TABLE_NAME 
													 FROM #JSON_TABLE_COLLECTION AS JTC
													 WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX) + '%'
						 END
						
						--BELOW STEP IS PROCESSED IF CURRENT SUBOBJECT'S PROPERTY NESTING LEVEL IS F.E. 3 AND INDEX IS F.E. 9 AND WE KNOW THAT THIS NESTING LEVEL HAS 4 COLUMNS,
						-- AND SOME PREVIOUS SUBOBJECTS ARE MISSING SOME NESTING LEVELS, AND IN THIS CASE WE FOUND SUCH MISSING LEVEL ___MISSING_LEVEL_OBJECT___, => @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = NULL
						IF @LAST_PROCESSED_OBJECT_PROPERTY_INDEX IS NULL
						 BEGIN
						  SET @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY = @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY + 1
						  CONTINUE
						 END

						--CHECK IF THIS OBJECT'S CURRENT NESTING LEVEL HAS NO DATA FOR THE FIRST COMPLEX OBJECT'S CURRENT LEVEL IN THE COLLECTION
						IF NOT EXISTS (
						  SELECT 1/0
						  FROM #JSON_TABLE_COLLECTION AS JTC
						  WHERE JTC.ID = @NESTING_LEVEL
						   AND JTC.TABLE_NAME <> @MISSING_LEVEL_OBJECT
						) AND @CURRENT_OBJECT_PROPERTY_INDEX <= @LAST_PROCESSED_OBJECT_PROPERTY_INDEX
						BEGIN
						 SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER - 1
						END

						IF @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX + 1 = @JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX
						 BEGIN
						   IF @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY > 0
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX + @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY * @LAST_PROCESSED_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1
							END
						   ELSE
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1
							END
						 END
						ELSE
						 BEGIN
						   IF @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY > 0
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX + @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY * @LAST_PROCESSED_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX
							END
						   ELSE
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX
							END
						 END

						--CHECK IF WE FOUND ANOTHER COPLEX OBJECT
						SET @BREAK_LOOP = DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT)
						IF @BREAK_LOOP = 1
						 BEGIN
							UPDATE JTC
							 SET
								JTC.INSERT_SELECT_DATA_ROW = DBO.GET_TRY_REPLACE_RESULT_STRING(@TRY_REPLACE_RESULT)
							FROM #JSON_TABLE_COLLECTION AS JTC
							WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX

							BREAK
						 END
						ELSE
						 BEGIN
							IF NOT EXISTS (
							  SELECT 1/0
							  FROM #JSON_TABLE_COLLECTION AS JTC
							  WHERE JTC.ID = @NESTING_LEVEL
							   AND JTC.TABLE_NAME <> @MISSING_LEVEL_OBJECT
							)
							 BEGIN
								SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER - 1
							 END
						 END

						SET @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = -1
						SET @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = -1
						SET @TRY_REPLACE_RESULT = N''
					 END

					--WE PROCESSED CURRENT LEVEL PROPERTY OF ANOTHER COMPLEX OBJECT, THEREFORE RESET TEMPORARY VARIABLES TO DEFAULT VALUES
					SET @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = -1
					SET @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX = -1
					SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = 0
					SET @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY = 0
					SET @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = -1
					SET @TRY_REPLACE_RESULT = N''
				 END
				ELSE
				 BEGIN
					UPDATE JTC
					 SET
						JTC.INSERT_SELECT_DATA_ROW = DBO.GET_TRY_REPLACE_RESULT_STRING(@TRY_REPLACE_RESULT)
					FROM #JSON_TABLE_COLLECTION AS JTC
					WHERE JTC.ID = @NESTING_LEVEL
				 END
			
				SET @TRY_REPLACE_RESULT = N''

			 	SET @VALIDATION_INDEX_START = 1
				WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
				 BEGIN
					 SELECT
						@INSERT_SELECT_STATEMENT = 'INSERT ' + JTC.TABLE_NAME + ' ' + JTC.INSERT_SELECT_DATA_ROW
					 FROM #JSON_TABLE_COLLECTION AS JTC
					 WHERE JTC.ID = @VALIDATION_INDEX_START
					  AND JTC.TABLE_NAME <> @SEPARATOR

					 IF @INSERT_SELECT_STATEMENT <> N''
					  BEGIN
						 EXEC (@INSERT_SELECT_STATEMENT)
						 
						 SET @INSERT_SELECT_STATEMENT = N''

						 IF @VALIDATION_INDEX_START = @VALIDATION_INDEX_END
						  BEGIN
							SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
							CONTINUE
						  END

						 UPDATE JTC
							SET
								JTC.INSERT_SELECT_DATA_ROW = JTC.INSERT_SELECT_TEMPLATE_HEADER
						 FROM #JSON_TABLE_COLLECTION AS JTC
						 WHERE JTC.ID = @VALIDATION_INDEX_START
					  END
					 SET @INSERT_SELECT_STATEMENT = N''
					 SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1					
				 END
				 
			  SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
			 END

			--THIS TAKES PLACE IMMEDIATELY AFTER WE'VE REACHED THE LAST PROPERTY OF THE LAST OBJECT IN THE COLLECTION
			IF @INDEX_START_POSITION > @INDEX_END_POSITION
			 CONTINUE

			--OTHERWISE STORE PREVIOUS OBJECT NUMBER AND APPLY FURTHER PROCESSING
		    SET @OBJECT_NUMBER_PREV = @OBJECT_NUMBER

			SELECT
				@PROPERTY_VALUE = ISNULL(JICTTI_2.PROPERTY_VALUE, @NULL_CONSTANT),
				@OBJECT_NUMBER = JICTTI_2.OBJECT_NUMBER,
				@NESTING_LEVEL = JICTTI_2.NESTING_LEVEL,
				@CURRENT_OBJECT_PROPERTY_INDEX = JICTTI_2.CURRENT_OBJECT_PROPERTY_INDEX
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI_2
			WHERE JICTTI_2.ID = @INDEX_START_POSITION
			   
			SELECT
				@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @NESTING_LEVEL

			--CHECK IF WE ARE PROCESSING ANOTHER COMPLEX JSON OBJECT UNDER CURRENT PARENT OBJECT ( DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT) = 0 ), IN OTHER WORDS ANOTHER COMPLEX PROPERTY
			IF DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT) = 0
			 BEGIN
					SET @TRY_REPLACE_RESULT = N''
				    SET @BREAK_LOOP = 0
					WHILE @BREAK_LOOP = 0
					 BEGIN
					    --CALCULATE NUMBER OF COMPLEX SUBOBJECTS PER PARENT OBJECT
						SELECT TOP (1)
							@JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = JTC.ID - 1,
							@JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX = JTC.ID,
							@JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER + 1
						FROM #JSON_TABLE_COLLECTION AS JTC
						WHERE JTC.TABLE_NAME = @SEPARATOR
						 AND JTC.ID > @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX
						ORDER BY JTC.ID

						--IF WE PROCESS LAST COMPLEX SUBOBJECT OF PARENT OBJECT FOR CURRENT NESTING LEVEL IN THE COLLECTION
						IF @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX + 1 = @JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX
						 BEGIN
							SELECT
								@LAST_PROCESSED_OBJECT_PROPERTY_INDEX = MAX(C.ORDINAL_POSITION) - 1
							FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS C
							WHERE C.TABLE_NAME LIKE (SELECT JTC.TABLE_NAME 
													 FROM #JSON_TABLE_COLLECTION AS JTC
													 WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1) + '%'
						 END
						ELSE
						 BEGIN
							SELECT
								@LAST_PROCESSED_OBJECT_PROPERTY_INDEX = MAX(C.ORDINAL_POSITION) - 1
							FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS C
							WHERE C.TABLE_NAME LIKE (SELECT JTC.TABLE_NAME 
													 FROM #JSON_TABLE_COLLECTION AS JTC
													 WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX) + '%'
						 END
						
						--BELOW STEP IS PROCESSED IF CURRENT SUBOBJECT'S PROPERTY NESTING LEVEL IS F.E. 3 AND INDEX IS F.E. 9 AND WE KNOW THAT THIS NESTING LEVEL HAS 4 COLUMNS,
						-- AND SOME PREVIOUS SUBOBJECTS ARE MISSING SOME NESTING LEVELS, AND IN THIS CASE WE FOUND SUCH MISSING LEVEL ___MISSING_LEVEL_OBJECT___, => @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = NULL
						IF @LAST_PROCESSED_OBJECT_PROPERTY_INDEX IS NULL
						 BEGIN
						  SET @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY = @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY + 1
						  CONTINUE
						 END
						
						--CHECK IF THIS OBJECT'S CURRENT NESTING LEVEL HAS NO DATA FOR THE FIRST COMPLEX OBJECT'S CURRENT LEVEL IN THE COLLECTION
						IF NOT EXISTS (
						  SELECT 1/0
						  FROM #JSON_TABLE_COLLECTION AS JTC
						  WHERE JTC.ID = @NESTING_LEVEL
						   AND JTC.TABLE_NAME <> @MISSING_LEVEL_OBJECT
						) AND @CURRENT_OBJECT_PROPERTY_INDEX <= @LAST_PROCESSED_OBJECT_PROPERTY_INDEX
						BEGIN
						 SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER - 1
						END

						IF @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX + 1 = @JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX
						 BEGIN
						   IF @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY > 0
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX + @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY * @LAST_PROCESSED_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1
							END
						   ELSE
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX - 1
							END
						 END
						ELSE
						 BEGIN
						   IF @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY > 0
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX + @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY * @LAST_PROCESSED_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX
							END
						   ELSE
						    BEGIN
								SELECT
									@TRY_REPLACE_RESULT = DBO.TRY_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX - @LAST_PROCESSED_OBJECT_PROPERTY_INDEX * @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
								FROM #JSON_TABLE_COLLECTION AS JTC
								WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX
							END
						 END

						--CHECK IF WE FOUND ANOTHER COPLEX OBJECT
						SET @BREAK_LOOP = DBO.CHECK_TRY_REPLACE_RESULT(@TRY_REPLACE_RESULT)
						IF @BREAK_LOOP = 1
						 BEGIN
							UPDATE JTC
							 SET
								JTC.INSERT_SELECT_DATA_ROW = DBO.GET_TRY_REPLACE_RESULT_STRING(@TRY_REPLACE_RESULT)
							FROM #JSON_TABLE_COLLECTION AS JTC
							WHERE JTC.ID = @NESTING_LEVEL + @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX

							BREAK
						 END
						ELSE
						 BEGIN
							IF NOT EXISTS (
							  SELECT 1/0
							  FROM #JSON_TABLE_COLLECTION AS JTC
							  WHERE JTC.ID = @NESTING_LEVEL
							   AND JTC.TABLE_NAME <> @MISSING_LEVEL_OBJECT
							)
							 BEGIN
								SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER - 1
							 END
						 END

						SET @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = -1
						SET @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = -1
						SET @TRY_REPLACE_RESULT = N''
					 END
					
					--WE PROCESSED CURRENT LEVEL PROPERTY OF ANOTHER COMPLEX OBJECT, THEREFORE RESET TEMPORARY VARIABLES TO DEFAULT VALUES
					SET @JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX = -1
					SET @JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX = -1
					SET @JSON_OBJECT_COMPLEX_PROPERTY_COUNTER = 0
					SET @MISSING_LEVEL_OBJECT_FOUND_MULTIPLED_BY = 0
					SET @LAST_PROCESSED_OBJECT_PROPERTY_INDEX = -1
					SET @TRY_REPLACE_RESULT = N''
			 END
		    ELSE
			 BEGIN
				UPDATE JTC
				 SET
					JTC.INSERT_SELECT_DATA_ROW = DBO.GET_TRY_REPLACE_RESULT_STRING(@TRY_REPLACE_RESULT)
				FROM #JSON_TABLE_COLLECTION AS JTC
				WHERE JTC.ID = @NESTING_LEVEL
			 END
			
			SET @TRY_REPLACE_RESULT = N''

		  SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
		 END
END