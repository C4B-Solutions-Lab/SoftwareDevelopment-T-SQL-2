-- ===============================================================================================================================================================================================
-- author:			�ukasz D�browski
-- company:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				lukaszdabrowski.com
-- creation date:	2016-04-12
-- description:		Returns C# property name in the form of PascalCase (default) or camelCase notation. Parameters are self-explaining.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ===============================================================================================================================================================================================

IF OBJECT_ID('CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME') IS NOT NULL
 DROP FUNCTION CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME
GO

CREATE FUNCTION CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME
(
 @P_COLUMN_NAME VARCHAR(MAX),
 @P_USE_PASCAL_CASE BIT = 1
)
RETURNS VARCHAR(MAX)
AS
 BEGIN
  DECLARE 
		  @PROPERTY_NAME AS VARCHAR(MAX) = '',
		  @UNDERSCORE AS CHAR(1) = '_',
		  @CURRENT_CHAR AS CHAR(1) = '',
		  @START AS INT = 1,
		  @END AS INT  = LEN(@P_COLUMN_NAME),
		  @NEXT_CHAR_MUST_START_WITH_CAPITAL_LETTER AS BIT = 1
  
  
  SET @P_COLUMN_NAME = LTRIM(RTRIM(@P_COLUMN_NAME))
  
  WHILE @START <= @END
   BEGIN
    SET @CURRENT_CHAR = SUBSTRING(@P_COLUMN_NAME, @START, 1)
    IF @CURRENT_CHAR = @UNDERSCORE
     BEGIN
      SET @NEXT_CHAR_MUST_START_WITH_CAPITAL_LETTER = 1
     END
    ELSE
     BEGIN
       IF @NEXT_CHAR_MUST_START_WITH_CAPITAL_LETTER = 1
		SET @PROPERTY_NAME = @PROPERTY_NAME + UPPER(@CURRENT_CHAR)
	   ELSE
		SET @PROPERTY_NAME = @PROPERTY_NAME + @CURRENT_CHAR
		
       SET @NEXT_CHAR_MUST_START_WITH_CAPITAL_LETTER = 0
     END
    
    SET @START = @START + 1
   END

   IF @P_USE_PASCAL_CASE = 0
    SET @PROPERTY_NAME = LOWER(SUBSTRING(@PROPERTY_NAME, 1,1)) + SUBSTRING(@PROPERTY_NAME, 2, LEN(@PROPERTY_NAME)-1)

  RETURN @PROPERTY_NAME
 END