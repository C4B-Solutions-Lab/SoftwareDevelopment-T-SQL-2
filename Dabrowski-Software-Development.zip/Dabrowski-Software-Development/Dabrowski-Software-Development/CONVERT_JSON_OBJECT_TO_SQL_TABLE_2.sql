-- =============================================================================================================================================================================================================================
-- author:				�ukasz D�browski
-- project:				DABROWSKI SOFTWARE DEVELOPMENT
-- www:				https://github.com/Dabrowski-Software-Development?tab=repositories
-- creation date:		2016-07-05
-- modification date:	2016-07-17
-- description:		    Converts data in the form of JSON format to a table. Support for SQL SERVER versions prior to SQL SERVER 2016.
--						End user is responsible for providing unique temporary table in the server context, bacause there is no unique solution to pick up the correct table
--						in case multiple sessions would create temp tables with the same name (SQL SERVER temp tables nature) in the same relatively short period of time.
--						"null" values in JSON object are converted to ___NULL___ literal. It is end-user responsibility to handle this value appropriately.
--						Date & time values are handled as in T-SQL, datetime value have to be separated with uppercase T letter, i.e. "2016-05-14T22:29:34"
--						This procedure depends on dbo.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED, dbo.SUBSTRING2 and dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE functions, which are included in this solution.	
--			            Due to implementation details of handling null values [___NULL___] columns of type CHAR, NCHAR, VARCHAR and NVARCHAR that have null values in JSON object have to have column size of at least 10 characters.	
--						This version recognizes complex JSON object, where each item consists of another valid JSON object. Level of nested JSON object is unlimited. Example below:
--																																							[{
--																																								"property1": "1",
--																																								"property2": "11",
--																																								"sub_obj": {
--																																										"sub_property1": "111",
--																																										"sub_property2": "1111",
--																																										"sub_obj2": {
--																																												"sub_sub_property1": "a",
--																																												"sub_sub_property2": "b"
--																																										}
--																																								},
--																																								"property3": "3"
--																																							 },
--																																							 {
--																																								"property1": "2",
--																																								"property2": "22",
--																																								"sub_obj": {
--																																										"sub_property1": "222",
--																																										"sub_property2": "2222",
--																																										 "sub_obj2": {
--																																												"sub_sub_property1": "C",
--																																												"sub_sub_property2": "D"
--																																										 }
--																																								},
--																																								"property3": "33"
--																																							}]
--					@P_JSON_COLLECTION -> complex JSON object beforementioned,
--					@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT -> names of tables in ASC order for each level respectively (names ONLY). Below is a table definition pseudocode i.e.
--						table_A(property1, property2, property3),table_B(sub_property1, sub_property2), table_C(sub_sub_property1, sub_sub_property2)
--						Based on this example value for param P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT should be 'table_A,table_B,table_C'
--					
--                  THIS VERSION DOES NOT recognize nesting collection ( [...] ) of JSON objects inside a single object YET.
--					Future version (2.0.0) will try to address this feature.
--                  This version IS NOT a replacement of CONVERT_JSON_OBJECT_TO_SQL_TABLE procedure. It is built upon that procedure and covers beforementioned complex JSON objects.
--					
-- WARNING:			THERE IS ONE LIMITATION AS FOR THIS ALGORITHM: AT THE CURRENT LEVEL STARTING FROM THE ROOT LEVEL (FIRST PROPERTY OF THE TOPMOST JSON OBJECT) ONE CAN DECLARE SINGLE INNSTANCE OF NESTED OBJECTS, i.e.
--					this object can be recognized by this algorithm:
--													{
--													  "property1": "2",
--													  "property2": "22",
--													  "sub_obj": {
--														"sub_property1": "222",
--														"sub_property2": "2222",
--														"sub_obj2": {
--															"sub_sub_property1": "C",
--															"sub_sub_property2": "D"
--														}
--													  },
--													 "property3": "33"
--													}
--					whereas below object:
--													{
--													  "property1": "2",
--													  "property2": "22",
--													  "sub_obj": {
--														"sub_property1": "222",
--														"sub_property2": "2222",
--														"sub_obj2": {
--															"sub_sub_property1": "C",
--															"sub_sub_property2": "D"
--														}
--													 },
--													 "property3": "33",
--													  "sub_obj_2": {
--														"sub_property1": "222",
--														"sub_property2": "2222",
--														"sub_obj2": {
--															"sub_sub_property1": "C",
--															"sub_sub_property2": "D"
--														}
--													 }
--													}
--                  cannnot be handled properly yet. NEXT VERSION 1.5.0 will address that feature.
--					In order to join tables provided as comma separated string (to get one row for each JSON object),
--					there is a requiremment to join all these tables with _TABLE_INTERNAL_PK_ column, which is generated internally.
--					Therefore this column name _TABLE_INTERNAL_PK_ is a reserved one and any table provided as comma separated string cannot contain column with such name.
--					First table containing such column name will raise an error.
--					
-- version:			1.1.0
-- changes:			old ordering was assumming that each nesting level object's properties' names were ASC-like compliant.
			/*	
														"sub_obj2": {
															"sub_sub_property1": "C",
															"sub_sub_property2": "D"
														}
														                                        <---------------  OK
														after convertion to table
														 
														table_1(column_C, column_D)
																	C        D



														"sub_obj2": {
															"sub_sub_property455555": "C",
															"sub_sub_property1": "D"
														}                                        <---------------  WRONG
														converted to table 
														table_1(column_C, column_D)
																	D       C
			*/

			/*
				OLD:
					SELECT
						JICTTI.*,
						ROW_NUMBER() OVER(PARTITION BY JICTTI.OBJECT_NUMBER, JICTTI.NESTING_LEVEL ORDER BY JICTTI.PROPERTY_NAME) AS CURRENT_OBJECT_PROPERTY_INDEX
					INTO #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2
					FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI

				NEW:
					SELECT
						JICTTI.*,
						ROW_NUMBER() OVER(PARTITION BY JICTTI.OBJECT_NUMBER, JICTTI.NESTING_LEVEL ORDER BY JICTTI.ID) AS CURRENT_OBJECT_PROPERTY_INDEX
					INTO #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2
					FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
			*/
--
--			Applying above changes results in appropriate transformation of JSON property's value to the right table column, beacuse this algorithm heavily relies on table's columns order and JSON object's properties order.\
--			It has to be 1-1 mapping between them.
--
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- =============================================================================================================================================================================================================================

IF OBJECT_ID ('CONVERT_JSON_OBJECT_TO_SQL_TABLE_2') IS NOT NULL
 DROP PROC CONVERT_JSON_OBJECT_TO_SQL_TABLE_2
GO


CREATE PROCEDURE CONVERT_JSON_OBJECT_TO_SQL_TABLE_2
(
 @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT AS NVARCHAR(MAX),
 @P_JSON_COLLECTION AS NVARCHAR(MAX)
)
AS
BEGIN
	   SET NOCOUNT ON;

	   DECLARE
		@ERROR_TEMPLATE AS NVARCHAR(MAX) = '',
		@ERROR_MESSAGE AS NVARCHAR(MAX) = ''


		--ADD NECESSARY COMMA TO THE END OF TABLES' NAMES IF OMITTED
		IF RIGHT(@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT, 1) <> ','
		 SET @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT = @P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT + ','

		--CREATE TEMP TABLE TO STORE TABLES' NAMES THAT WILL HOLD JSON DATA
		CREATE TABLE #JSON_TABLE_COLLECTION
		(
			ID INT,
			TABLE_NAME SYSNAME
		)
		
		INSERT #JSON_TABLE_COLLECTION
		SELECT
			CT.ID,
			CT.CUSTOM_COLUMN 
		FROM DBO.CREATE_CUSTOM_TABLE(@P_COMMA_SEPARATED_TEMP_TABLES_NAMES_TO_STORE_JSON_OBJECT, DEFAULT, DEFAULT, DEFAULT, DEFAULT) AS CT


		--VALIDATE TABLES NAMES
		DECLARE
			@VALIDATION_INDEX_START AS INT = 1,
			@VALIDATION_INDEX_END AS INT = -1,
			@TABLE_NAME AS SYSNAME = ''

		SELECT @VALIDATION_INDEX_END = MAX(JTC.ID) FROM #JSON_TABLE_COLLECTION AS JTC

		WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
		 BEGIN
			SELECT
				@TABLE_NAME = JTC.TABLE_NAME
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @VALIDATION_INDEX_START
			
			IF NOT EXISTS (
				SELECT 1/0
				FROM tempdb.INFORMATION_SCHEMA.TABLES AS T
				WHERE T.TABLE_NAME LIKE @TABLE_NAME + '%'
			)
			BEGIN
				SET @ERROR_TEMPLATE = 'Temporary table ' + CAST(@TABLE_NAME AS VARCHAR(MAX)) + ' does not exist.'
				SET @ERROR_MESSAGE = ''
	   			RAISERROR (
							@ERROR_TEMPLATE,
							16,
							1,
							@ERROR_TEMPLATE,
							N''
						  )
				BREAK;
			END

			SET @TABLE_NAME = ''
			SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
		 END
		 
		--RESET @VALIDATION_INDEX_START TO 1
		SET @VALIDATION_INDEX_START = 1


		--ADD TWO COLUMNS TO STORE [INSERT SELECT TEMPLATE] && [INSERT SELECT DATA ROW] FOR EACH TABLE
		ALTER TABLE #JSON_TABLE_COLLECTION ADD INSERT_SELECT_TEMPLATE_HEADER NVARCHAR(MAX) DEFAULT N''
		ALTER TABLE #JSON_TABLE_COLLECTION ADD INSERT_SELECT_DATA_ROW NVARCHAR(MAX) DEFAULT N''

		--CREATE INSERT SELECT TEMPLATE
		DECLARE 
			@MIN_ORDINAL_POSITION AS INT = 1,
			@MIN_ORDINAL_POSITION_TO_STRING AS VARCHAR(MAX) = '',
			@MAX_ORDINAL_POSITION AS INT = -1,
			@COLUMN_NAME AS SYSNAME = '',
			@DATA_TYPE AS SYSNAME = '',
			@COLUMN_FULL_TYPE AS SYSNAME = '',
			@DYNAMIC_INSERT_QUERY AS NVARCHAR(MAX) = '',
			@SYSTEM_TYPE_ID AS TINYINT,
			@MAX_LENGTH AS SMALLINT,
			@PRECISION AS TINYINT,
			@SCALE AS TINYINT,

			@JSON_OBJECT_LAST_PROPERTY_ID AS INT = -1,
			@JSON_DATA_FIRST_ROW AS INT = 1,
			@JSON_DATA_FIRST_ROW_TO_STRING AS VARCHAR(MAX) = '',
			@JSON_DATA_LAST_ROW AS INT = -1,
			@INSERT_QUERY AS NVARCHAR(MAX) = '',
			@PROPERTY_VALUE AS NVARCHAR(MAX) = '',
			@DO_REPLACEMENT_WITH_DIVISION AS INT = 0,
			@UNION_ALL AS SYSNAME = ' UNION ALL ',
			@PK_INTERNAL_TABLE_NAME_PLACEHOLDER AS CHAR(18) = '{__________x_%^$}',
			@PK_INTERNAL_TABLE_NAME AS CHAR(19) = '_TABLE_INTERNAL_PK_'

		DECLARE
			@ADD_INTERNAL_PRIVATE_KEY_TEMPLATE AS NVARCHAR(MAX) = 'ALTER TABLE ' + @PK_INTERNAL_TABLE_NAME_PLACEHOLDER + ' ADD ' + @PK_INTERNAL_TABLE_NAME + ' INT IDENTITY',
			@ADD_INTERNAL_PRIVATE_KEY AS NVARCHAR(MAX) = ''


		WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
		 BEGIN
			SELECT
				@TABLE_NAME = JTC.TABLE_NAME
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @VALIDATION_INDEX_START

			SELECT 
				T.ORDINAL_POSITION,
				T.COLUMN_NAME,
				T.DATA_TYPE
			INTO #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE
			FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS T
			WHERE T.TABLE_NAME LIKE @TABLE_NAME + '%'

			IF EXISTS (
				SELECT 1/0 
				FROM #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE
				WHERE COLUMN_NAME = @PK_INTERNAL_TABLE_NAME
			)
			 BEGIN
				SET @ERROR_TEMPLATE = 'Table ' + @TABLE_NAME +  ' contains column ' + @PK_INTERNAL_TABLE_NAME + ', which is a reserved column name due to implementation details and cannot exist with such name in this table. Change column name.'
				RAISERROR (
							@ERROR_TEMPLATE,
							16,
							1,
							@ERROR_TEMPLATE,
							N''
						  )
				BREAK;
			 END

			SELECT
				@MAX_ORDINAL_POSITION = MAX(EUTBOTT.ORDINAL_POSITION)
			FROM #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE AS EUTBOTT
			SET @DYNAMIC_INSERT_QUERY = ' SELECT '


			--CREATE SELECT STATEMENT CONSISTING OF ALL THE COLUMNS IN THE TABLE
			WHILE @MIN_ORDINAL_POSITION <= @MAX_ORDINAL_POSITION
			 BEGIN
				SELECT
					@COLUMN_NAME = EUT.COLUMN_NAME,
					@DATA_TYPE = EUT.DATA_TYPE
				FROM #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE AS EUT
				WHERE EUT.ORDINAL_POSITION = @MIN_ORDINAL_POSITION

				SET @COLUMN_FULL_TYPE =  dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE(@COLUMN_NAME, @DATA_TYPE, @TABLE_NAME, 1)

				SET @MIN_ORDINAL_POSITION_TO_STRING = CAST(@MIN_ORDINAL_POSITION AS VARCHAR(MAX))
				SET @DYNAMIC_INSERT_QUERY = @DYNAMIC_INSERT_QUERY + 'CAST({_________________$' + @MIN_ORDINAL_POSITION_TO_STRING + '} AS ' + @COLUMN_FULL_TYPE + '), '

				SET @MIN_ORDINAL_POSITION = @MIN_ORDINAL_POSITION + 1
			 END
		 
			SET @DYNAMIC_INSERT_QUERY = RTRIM(@DYNAMIC_INSERT_QUERY)

			SET @DYNAMIC_INSERT_QUERY = LEFT(@DYNAMIC_INSERT_QUERY, LEN(@DYNAMIC_INSERT_QUERY) - 1)

			--UPDATE CURRENT TABLE'S INSERT SELECT TEMPLATE
			UPDATE JTC
			 SET
				JTC.INSERT_SELECT_TEMPLATE_HEADER = @DYNAMIC_INSERT_QUERY,
				JTC.INSERT_SELECT_DATA_ROW = @DYNAMIC_INSERT_QUERY
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @VALIDATION_INDEX_START
			
			--ADD IDENTITY COLUMN TO TABLE
			SET @ADD_INTERNAL_PRIVATE_KEY = REPLACE(@ADD_INTERNAL_PRIVATE_KEY_TEMPLATE, @PK_INTERNAL_TABLE_NAME_PLACEHOLDER, @TABLE_NAME)
			EXEC (@ADD_INTERNAL_PRIVATE_KEY)
			SET @ADD_INTERNAL_PRIVATE_KEY = ''

			--RESET NECESSARY VARIABLES TO DEFAULT VALUES
			SET @MIN_ORDINAL_POSITION = 1
			SET @MAX_ORDINAL_POSITION = -1
			SET @DYNAMIC_INSERT_QUERY = ''
			DROP TABLE #EXTERNAL_USER_TABLE_BASED_ON_TEMPORARY_TABLE

			SET @TABLE_NAME = ''
			SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
		 END


		--VALIDATE JSON COLLECTION
		DECLARE @EMPTY_STRING AS VARCHAR = ''
		DECLARE @ENTER AS CHAR(2) = CHAR(13)+CHAR(10)
		DECLARE @TABULATOR AS CHAR(1) = CHAR(9)
		DECLARE @JSON_COLLECTION AS NVARCHAR(MAX) = REPLACE(REPLACE(LTRIM(RTRIM(@P_JSON_COLLECTION)), @ENTER, ''), @TABULATOR, @EMPTY_STRING)
		DECLARE @JSON_COLLECTION_LENGTH AS INT = LEN(@JSON_COLLECTION)
		DECLARE @COMMA AS CHAR(1) = ','
		DECLARE @COLON AS CHAR(1) = ':'
		DECLARE @QUOTATION AS CHAR(1) = '"'
		DECLARE @OPENING_CURLY_BRACE AS CHAR(1) = '{'
		DECLARE @CLOSING_CURLY_BRACE AS CHAR(1) = '}'
		DECLARE @JSON_PROPERTY_NULL_VALUE AS CHAR(4) = 'null'
		DECLARE @NULL_CONSTANT AS CHAR(10) = '___NULL___'
		
		DECLARE @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET AS BIT = 0
		
		IF ((@JSON_COLLECTION_LENGTH - LEN(REPLACE(REPLACE(@JSON_COLLECTION, @OPENING_CURLY_BRACE, @EMPTY_STRING), @CLOSING_CURLY_BRACE, @EMPTY_STRING))) / LEN(@COMMA)) % 2 = 0
		 SET @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET = 1

	    IF @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET = 0
		 BEGIN
			SET @ERROR_TEMPLATE = 'JSON collection does not represent valid JSON. Number of opening and closing curly brackets mismatch.'
			SET @ERROR_MESSAGE = ''
	   		RAISERROR (
						@ERROR_TEMPLATE,
						16,
						1,
						@ERROR_TEMPLATE,
						N''
					  )
			 RETURN
		 END
		
		--REMOVE FIRST OPENING AND LAST CLOSING SQUARE BRACKET
		SET @JSON_COLLECTION = RIGHT(@JSON_COLLECTION, LEN(@JSON_COLLECTION) - 1)
		SET @JSON_COLLECTION = LEFT(@JSON_COLLECTION, LEN(@JSON_COLLECTION) - 1)
		SET @JSON_COLLECTION = LTRIM(RTRIM(@JSON_COLLECTION)) + @COMMA
		
		--INSERT EACH OBJECT INTO TABLE
		CREATE TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL(ID INT, JSON_ITEM NVARCHAR(MAX))
		INSERT #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
		SELECT
			JT.ID,
			JT.CUSTOM_COLUMN 
		FROM dbo.CREATE_CUSTOM_TABLE(@JSON_COLLECTION, DEFAULT, DEFAULT, DEFAULT, DEFAULT) AS JT


		ALTER TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL ADD PROPERTY_NAME NVARCHAR(MAX), PROPERTY_VALUE NVARCHAR(MAX), NESTING_LEVEL BIGINT, OBJECT_NUMBER BIGINT

		DECLARE
			@INDEX_START_POSITION AS INT = 1,
			@INDEX_INCREMENT_STEP_OF_OBJECT_END AS INT = -1,
			@INDEX_END_POSITION AS INT = -1,
	 		@NESTING_LEVEL AS INT = 1,
			@CURRENT_TRAVERSED_ITEM AS NVARCHAR(MAX)= '',
			@CURRENT_TRAVERSED_ITEM_ENDING_CURLY_BRACKETS AS NVARCHAR(MAX)= ''

		SET @INDEX_INCREMENT_STEP_OF_OBJECT_END = (
													SELECT
														(SELECT COUNT_BIG(*) FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL)  / COUNT_BIG(*) AS INDEX_INCREMENT_STEP_OF_OBJECT_END
													FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL WHERE LEFT(LTRIM(JSON_ITEM), 1) = '{'
												  )
		SELECT @INDEX_END_POSITION = MAX(ID) FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL

		WHILE @INDEX_START_POSITION <= @INDEX_END_POSITION
		BEGIN
			SELECT
				@CURRENT_TRAVERSED_ITEM = LTRIM(RTRIM(REPLACE(REPLACE(JSON_ITEM, CHAR(9), ''), CHAR(13)+CHAR(10), '')))
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
			WHERE ID = @INDEX_START_POSITION

			IF @INDEX_START_POSITION = 1 OR @INDEX_START_POSITION % @INDEX_INCREMENT_STEP_OF_OBJECT_END = 1 --FIRST PROPERTY OF NEXT (NOW CURRENT) OBJECT WAS PROCESSED, SO CUT OUT FIRST OPENING CURLY BRACE
			 SET @CURRENT_TRAVERSED_ITEM = SUBSTRING(@CURRENT_TRAVERSED_ITEM, 2, LEN(@CURRENT_TRAVERSED_ITEM))
			ELSE IF @INDEX_START_POSITION % @INDEX_INCREMENT_STEP_OF_OBJECT_END = 0 --LAST PROPERTY OF CURRENT OBJECT WAS PROCESSED, SO RESET NESTING LEVEL TO INITIAL VALUE: 1
			 BEGIN
				SET @CURRENT_TRAVERSED_ITEM = DBO.SUBSTRING2(@CURRENT_TRAVERSED_ITEM, LEN(@CURRENT_TRAVERSED_ITEM), LEN(@CURRENT_TRAVERSED_ITEM)-1, 1)
			 END

			IF CHARINDEX('{', @CURRENT_TRAVERSED_ITEM) = 0 -- CURRENT NESTING LEVEL'S PROPERTY:VALUE PAIR
			  BEGIN
			    UPDATE JICTTI
					SET
						JICTTI.PROPERTY_NAME = SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM) + 1, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM) - 3),
						JICTTI.PROPERTY_VALUE = 
												NULLIF(SUBSTRING(
																 @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3,
																 CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3) - CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0)-3
																)
													   ,
													   @JSON_PROPERTY_NULL_VALUE
													  ),
						JICTTI.NESTING_LEVEL = @NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
				WHERE JICTTI.ID = @INDEX_START_POSITION

				--CHECK IF CURRENT NESTING LEVEL'S PROPERTY:VALUE PAIR IS LAST ONE AT THIS LEVEL. IF SO DECREASE NESTING LEVEL BY 1
				IF CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0
				 SET @NESTING_LEVEL = @NESTING_LEVEL - LEN(LTRIM(RTRIM(DBO.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED(@CURRENT_TRAVERSED_ITEM, '}]'))))

			  END
			ELSE IF CHARINDEX('{', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0 -- CURRENT NESTING LEVEL'S NESTED OBJECT -> CURRENT NESTING LEVEL ++
			 BEGIN
			  SET @NESTING_LEVEL = @NESTING_LEVEL + 1
			  SET @CURRENT_TRAVERSED_ITEM = LTRIM(RTRIM(SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX('{', @CURRENT_TRAVERSED_ITEM)+1, LEN(@CURRENT_TRAVERSED_ITEM))))
			    UPDATE JICTTI
					SET
						JICTTI.PROPERTY_NAME = SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM) + 1, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM) - 3),
						JICTTI.PROPERTY_VALUE = 
												NULLIF(SUBSTRING(
																 @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3,
																 CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3) - CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0)-3
																)
													   ,
													   @JSON_PROPERTY_NULL_VALUE
													  ),
						JICTTI.NESTING_LEVEL = @NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
				WHERE JICTTI.ID = @INDEX_START_POSITION
			 END
			ELSE IF CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0 -- CURRENT NESTING LEVEL'S OBJECT LAST PROPERTY:VALUE PAIR-> CURRENT NESTING LEVEL --
			 BEGIN
			  SET @NESTING_LEVEL = @NESTING_LEVEL - 1
			  SET @CURRENT_TRAVERSED_ITEM_ENDING_CURLY_BRACKETS = LTRIM(RTRIM(SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX('}', @CURRENT_TRAVERSED_ITEM)+1, LEN(@CURRENT_TRAVERSED_ITEM))))
			  SET @CURRENT_TRAVERSED_ITEM = LTRIM(RTRIM(SUBSTRING(@CURRENT_TRAVERSED_ITEM, 1, CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM)))-1)))
			    UPDATE JICTTI
					SET
						JICTTI.PROPERTY_NAME = SUBSTRING(@CURRENT_TRAVERSED_ITEM, CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM) + 1, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM) - 3),
						JICTTI.PROPERTY_VALUE = 
												NULLIF(SUBSTRING(
																 @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3,
																 CHARINDEX(@QUOTATION, @CURRENT_TRAVERSED_ITEM, CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0) + 3) - CHARINDEX(@COLON, @CURRENT_TRAVERSED_ITEM, 0)-3
																)
													   ,
													   @JSON_PROPERTY_NULL_VALUE
													  ),
						JICTTI.NESTING_LEVEL = @NESTING_LEVEL
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
				WHERE JICTTI.ID = @INDEX_START_POSITION

				IF CHARINDEX('}', LTRIM(RTRIM(@CURRENT_TRAVERSED_ITEM))) > 0
				 SET @NESTING_LEVEL = @NESTING_LEVEL - LEN(LTRIM(RTRIM(DBO.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED(@CURRENT_TRAVERSED_ITEM, '}]'))))

			 END

			--UPDATE WHICH PROPERTY'S OBJECT NUMBER WE ARE DEALING WITH
			UPDATE JICTTI
			 SET
				JICTTI.OBJECT_NUMBER = CASE WHEN ID % @INDEX_INCREMENT_STEP_OF_OBJECT_END = 0 THEN ID / @INDEX_INCREMENT_STEP_OF_OBJECT_END ELSE ID / @INDEX_INCREMENT_STEP_OF_OBJECT_END + 1 END
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
			WHERE JICTTI.ID = @INDEX_START_POSITION

			SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
		END

		SELECT
			JICTTI.*,
			ROW_NUMBER() OVER(PARTITION BY JICTTI.OBJECT_NUMBER, JICTTI.NESTING_LEVEL ORDER BY JICTTI.ID) AS CURRENT_OBJECT_PROPERTY_INDEX
		INTO #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2
		FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI


		--DISTRIBUTE EACH RECORD TO APPROPRIATE TABLE [ DECLARE NECESSARY VARIABLES]
		DECLARE
			@OBJECT_NUMBER AS INT = -1,
			@OBJECT_NUMBER_PREV AS INT = -1,
			@CURRENT_OBJECT_PROPERTY_INDEX AS INT = -1,
			@INSERT_SELECT_STATEMENT AS NVARCHAR(MAX) = N''

		SET @INDEX_START_POSITION = 1		
		SET @TABLE_NAME = ''
		SET @PROPERTY_VALUE = ''
		SET @NESTING_LEVEL = -1

		WHILE @INDEX_START_POSITION <= @INDEX_END_POSITION
		 BEGIN
			--IF WE ARE ABOUT TO START PROCESSING ANOTHER OBJECT, INSERT INTO CONNECTED TABLES CURRENT ONE'S STATE
			IF @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> -1 AND @OBJECT_NUMBER <> @OBJECT_NUMBER_PREV
			 BEGIN
			 	SET @VALIDATION_INDEX_START = 1
				WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
				 BEGIN
					 SELECT
						@INSERT_SELECT_STATEMENT = 'INSERT ' + JTC.TABLE_NAME + ' ' + JTC.INSERT_SELECT_DATA_ROW
					 FROM #JSON_TABLE_COLLECTION AS JTC
					 WHERE JTC.ID = @VALIDATION_INDEX_START

					 EXEC (@INSERT_SELECT_STATEMENT)

					 SET @INSERT_SELECT_STATEMENT = N''
					 
					 UPDATE JTC
						SET
							JTC.INSERT_SELECT_DATA_ROW = JTC.INSERT_SELECT_TEMPLATE_HEADER
					 FROM #JSON_TABLE_COLLECTION AS JTC
					 WHERE JTC.ID = @VALIDATION_INDEX_START

					 SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
				 END
				 --THIS LOGIC APPLIES ONLY UNTIL WE REACHED THE LAST OBJECT
				 IF @INDEX_START_POSITION <> @INDEX_END_POSITION
					SET @INDEX_START_POSITION = @INDEX_START_POSITION - 1
			 END
			ELSE IF @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> -1 AND @INDEX_START_POSITION = @INDEX_END_POSITION
			 BEGIN
				SELECT
					@PROPERTY_VALUE = ISNULL(JICTTI_2.PROPERTY_VALUE, @NULL_CONSTANT),
					@OBJECT_NUMBER = JICTTI_2.OBJECT_NUMBER,
					@NESTING_LEVEL = JICTTI_2.NESTING_LEVEL,
					@CURRENT_OBJECT_PROPERTY_INDEX = JICTTI_2.CURRENT_OBJECT_PROPERTY_INDEX
				FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI_2
				WHERE JICTTI_2.ID = @INDEX_START_POSITION

				UPDATE JTC
				 SET
					JTC.INSERT_SELECT_DATA_ROW = REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
				FROM #JSON_TABLE_COLLECTION AS JTC
				WHERE JTC.ID = @NESTING_LEVEL
				
			 	SET @VALIDATION_INDEX_START = 1
				WHILE @VALIDATION_INDEX_START <= @VALIDATION_INDEX_END
				 BEGIN
					 SELECT
						@INSERT_SELECT_STATEMENT = 'INSERT ' + JTC.TABLE_NAME + ' ' + JTC.INSERT_SELECT_DATA_ROW
					 FROM #JSON_TABLE_COLLECTION AS JTC
					 WHERE JTC.ID = @VALIDATION_INDEX_START

					 EXEC (@INSERT_SELECT_STATEMENT)
					 
					 SET @INSERT_SELECT_STATEMENT = N''
					 
					 UPDATE JTC
						SET
							JTC.INSERT_SELECT_DATA_ROW = JTC.INSERT_SELECT_TEMPLATE_HEADER
					 FROM #JSON_TABLE_COLLECTION AS JTC
					 WHERE JTC.ID = @VALIDATION_INDEX_START
					
					 SET @VALIDATION_INDEX_START = @VALIDATION_INDEX_START + 1
					
				 END
				 
			  SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
			 END


			--STORE PREVIOUS OBJECT NUMBER
		    SET @OBJECT_NUMBER_PREV = @OBJECT_NUMBER

			SELECT
				@PROPERTY_VALUE = ISNULL(JICTTI_2.PROPERTY_VALUE, @NULL_CONSTANT),
				@OBJECT_NUMBER = JICTTI_2.OBJECT_NUMBER,
				@NESTING_LEVEL = JICTTI_2.NESTING_LEVEL,
				@CURRENT_OBJECT_PROPERTY_INDEX = JICTTI_2.CURRENT_OBJECT_PROPERTY_INDEX
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2 AS JICTTI_2
			WHERE JICTTI_2.ID = @INDEX_START_POSITION

			UPDATE JTC
			 SET
				JTC.INSERT_SELECT_DATA_ROW = REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
			FROM #JSON_TABLE_COLLECTION AS JTC
			WHERE JTC.ID = @NESTING_LEVEL

		  SET @INDEX_START_POSITION = @INDEX_START_POSITION + 1
		 END
END