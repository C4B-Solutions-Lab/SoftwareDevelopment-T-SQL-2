-- ======================================================================================================================================================================================================
-- author:			�ukasz D�browski
-- project:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				https://github.com/Dabrowski-Software-Development?tab=repositories
-- creation date:	2016-04-12
-- description:		Returns data that can be displayed in HTML format and optionally sends email from within database with provided credentials.
--					Sending email assumes that appropriate account (provided as a parameter) and profile are crated and executing user was granted with sufficient privilages to execute this operation.
--					"The ExamplaryDatabaseMailConfiguration.sql file" in this solution is a TSQL template for configuring Database Mail feature. Please refer to this file for details.
--					SQL Server Agent must be enabled as well as sending email database option:
--																						type:
--																						*******************************************************
--																						*													  *
--																						*     sp_configure 'show advanced options', 1		  *
--																						*     GO											  *
--																						*     RECONFIGURE WITH OVERRIDE						  *
--																						*													  *
--																						*     and look for sth called %XPs%, set it  to 1	  *
--																	                    *                                                     *
--																						*******************************************************
--					Parameters are self-explaining except for @P_BODY_CONTENT_VALID_CSS_RULES. Value for this must be like this, i.e. backgroumd-color : blue; float: left; font_family: monospace etc.
--					Future version will cover more advanced CSS techniques. This version simply applies basic CSS rules.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ======================================================================================================================================================================================================

IF OBJECT_ID('APPLY_CSS_RULES_AND_OPTIONALLY_SEND_EMAIL_AS_HTML_OR_PLAIN_TEXT') IS NOT NULL
 DROP PROC APPLY_CSS_RULES_AND_OPTIONALLY_SEND_EMAIL_AS_HTML_OR_PLAIN_TEXT
GO

CREATE PROC APPLY_CSS_RULES_AND_OPTIONALLY_SEND_EMAIL_AS_HTML_OR_PLAIN_TEXT
(
 @P_BODY_CONTENT VARCHAR(MAX) = '',
 @P_BODY_CONTENT_FORMART AS CHAR(4) = 'HTML',
 @P_SUBJECT AS VARCHAR(MAX) = '',
 @P_COLON_SEPARATED_LIST_OF_RECIPIENTS AS VARCHAR(MAX) = '',
 @P_SEND_EMAIL BIT = 0,
 @P_USER_PROFILE_NAME AS VARCHAR(MAX) = '',
 @P_BODY_VALID_CSS_RULES AS VARCHAR(MAX) = '',
 @P_BODY_CONTENT_VALID_CSS_RULES AS VARCHAR(MAX) = ''
)
AS
 BEGIN
  DECLARE @HTML_OUTPUT AS VARCHAR(MAX) = '
											<html>
												<body style="$1">
													<div class="main" style="$2">
														$3
													</div>
												</body>
										    </html>
										 '
										   
  --PUT USER CONTENT INTO DIV AND APPLY CSS rules
  SET @HTML_OUTPUT = REPLACE(@HTML_OUTPUT, '$1', @P_BODY_VALID_CSS_RULES);
  SET @HTML_OUTPUT = REPLACE(@HTML_OUTPUT, '$2', @P_BODY_CONTENT_VALID_CSS_RULES);
  SET @HTML_OUTPUT = REPLACE(@HTML_OUTPUT, '$3', @P_BODY_CONTENT);

  IF @P_SEND_EMAIL = 1
   BEGIN
	  --APPLY SET OF USEFUL CHECKS TO FACILITATE SENDING EMAIL
	  IF RIGHT(@P_COLON_SEPARATED_LIST_OF_RECIPIENTS, 1) <> ';'
	   SET @P_COLON_SEPARATED_LIST_OF_RECIPIENTS = @P_COLON_SEPARATED_LIST_OF_RECIPIENTS + ';'

	  IF UPPER(@P_BODY_CONTENT_FORMART) <> 'HTML' AND UPPER(@P_BODY_CONTENT_FORMART) <> 'TEXT'
	   SET @P_BODY_CONTENT_FORMART = 'TEXT'


	  --SEND EMAIL
	  EXEC msdb.dbo.sp_send_dbmail
									@profile_name = @P_USER_PROFILE_NAME,
									@recipients = @P_COLON_SEPARATED_LIST_OF_RECIPIENTS,
									@subject = @P_SUBJECT,
									@body = @HTML_OUTPUT,
									@body_format = @P_BODY_CONTENT_FORMART
   END
      
  SELECT @HTML_OUTPUT
 END