-- ===============================================================================================================================================================================================
-- author:			�ukasz D�browski
-- project:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				https://github.com/Dabrowski-Software-Development?tab=repositories
-- creation date:	2016-04-12
-- description:		Returns table column data converted to VARCHAR(MAX) as JSON.
--					This procedure is dependant on CONVERT_QUERY_RESULT_TO_JSON_FORMAT procedure in this solution.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ===============================================================================================================================================================================================

IF OBJECT_ID('GET_TABLE_COLUMN_DATA_AS_JSON') IS NOT NULL
 DROP PROC GET_TABLE_COLUMN_DATA_AS_JSON
GO

CREATE PROCEDURE GET_TABLE_COLUMN_DATA_AS_JSON
(
 @P_TABLE_NAME AS SYSNAME,
 @P_COLUMN_NAME AS SYSNAME,
 @ROW_NUMBER AS BIGINT,
 @LAST_ROW_COLUMN AS BIT,
 @P_TABLE_COLUMN_DATA AS VARCHAR(MAX) OUTPUT
)
AS
 BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #RESULT(DATA VARCHAR(MAX))
	
	DECLARE @SQL AS VARCHAR(MAX) = '
										;WITH CTE AS (
											SELECT ' +  @P_COLUMN_NAME + ', ROW_NUMBER() OVER(ORDER BY (SELECT 0)) AS RN FROM ' + @P_TABLE_NAME + '
										)
										SELECT ' + @P_COLUMN_NAME + ' FROM CTE WHERE RN = ' + CAST(@ROW_NUMBER AS VARCHAR(MAX))
	
	INSERT #RESULT
	EXEC (@SQL)

	IF @LAST_ROW_COLUMN = 1
	 SELECT @P_TABLE_COLUMN_DATA = '"' + @P_COLUMN_NAME + '":"' +  ISNULL(DATA, 'null') + '"' FROM #RESULT
	ELSE
	 SELECT @P_TABLE_COLUMN_DATA = '"' + @P_COLUMN_NAME + '":"' +  ISNULL(DATA, 'null') + '",' FROM #RESULT
 END