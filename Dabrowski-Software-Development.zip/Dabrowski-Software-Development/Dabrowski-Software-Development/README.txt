starting from the root object:

1. subobjects have different structures + some of them have 1 complex subobject
  a. first complex object has data on each level
  b. at least one level is missing data
   I (LAST NESTING LEVEL)
   II (LAST - 1 NESTING LEVEL)

2. all subobjects have the same structure




 ______________________________________________________________________________________________________________________________________________________________________________________
|																																													   |
|																																													   | 
| ALL THE ABOVE CASES ARE PROVIDED WITH SAMPLES IN THIS SOLUTION. LOOK INTO FOLDER CALLED testing.																					   |
|																																													   |
| FIRST INPUT PARAMETER REFLECTS SINGLE MAIN JSON OBJECT, i.e. in the provided samples such main object consists of max. 3 complex properties.										   |
| Each complex property is separated from another by using |																														   |	
|																																													   |
|										'#MY_ROOT_TABLE, -- this table reflects properties of main object																			   |
|										 #MY_SUB_TABLE,#MY_SUB_SUB_TABLE,#MY_SUB_SUB_SUB_TABLE, -- these tables reflect properties of first complex object under main object		   |
|										  (#MY_SUB_TABLE -> nesting level 2) (#MY_SUB_SUB_TABLE -> nesting level 3) (#MY_SUB_SUB_SUB_TABLE -> nesting level 4)                         |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 #2_MY_SUB_TABLE,#2_MY_SUB_SUB_TABLE,#2_MY_SUB_SUB_SUB_TABLE, --these tables reflect properties of second complex object under main object     |
|										  (#2_MY_SUB_TABLE -> nesting level 2) (#2_MY_SUB_SUB_TABLE -> nesting level 3) (#2_MY_SUB_SUB_SUB_TABLE -> nesting level 4)                   |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 #3_MY_SUB_TABLE,#3_MY_SUB_SUB_TABLE,#3_MY_SUB_SUB_SUB_TABLE, --these tables reflect properties of third complex object under main object	   |
|										  (#3_MY_SUB_TABLE -> nesting level 2) (#3_MY_SUB_SUB_TABLE -> nesting level 3) (#3_MY_SUB_SUB_SUB_TABLE -> nesting level 4)                   |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   | 
|										 #4_MY_SUB_TABLE,#4_MY_SUB_SUB_TABLE,#4_MY_SUB_SUB_SUB_TABLE --these tables reflect properties of fourth complex object under main object      |
|										  (#4_MY_SUB_TABLE -> nesting level 2) (#4_MY_SUB_SUB_TABLE -> nesting level 3) (#4_MY_SUB_SUB_SUB_TABLE -> nesting level 4)                   |
|																				  |																									   |
| SECOND INPUT PARAMETER IS JSON COLLCTION																																			   |
|																																													   |
|______________________________________________________________________________________________________________________________________________________________________________________|