IF OBJECT_ID('tempdb.dbo.#4_MY_SUB_SUB_SUB_TABLE') IS NOT NULL
 DROP TABLE #4_MY_SUB_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#4_MY_SUB_SUB_TABLE') IS NOT NULL
 DROP TABLE #4_MY_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#4_MY_SUB_TABLE') IS NOT NULL
 DROP TABLE #4_MY_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#3_MY_SUB_SUB_SUB_TABLE') IS NOT NULL
 DROP TABLE #3_MY_SUB_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#3_MY_SUB_SUB_TABLE') IS NOT NULL
 DROP TABLE #3_MY_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#3_MY_SUB_TABLE') IS NOT NULL
 DROP TABLE #3_MY_SUB_TABLE

 IF OBJECT_ID('tempdb.dbo.#2_MY_SUB_SUB_SUB_TABLE') IS NOT NULL
  DROP TABLE #2_MY_SUB_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#2_MY_SUB_SUB_TABLE') IS NOT NULL
 DROP TABLE #2_MY_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#2_MY_SUB_TABLE') IS NOT NULL
DROP TABLE #2_MY_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#MY_SUB_SUB_SUB_TABLE') IS NOT NULL
DROP TABLE #MY_SUB_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#MY_SUB_SUB_TABLE') IS NOT NULL
DROP TABLE #MY_SUB_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#MY_SUB_TABLE') IS NOT NULL
DROP TABLE #MY_SUB_TABLE

IF OBJECT_ID('tempdb.dbo.#MY_ROOT_TABLE') IS NOT NULL
DROP TABLE #MY_ROOT_TABLE

GO

CREATE TABLE #MY_ROOT_TABLE(COLUMN_1 int, COLUMN_2 NVARCHAR(100), COLUMN_3 int, COLUMN_4 int, COLUMN_5 int)

CREATE TABLE #MY_SUB_TABLE(COLUMN_1 int, COLUMN_2 INT, COLUMN_3 NVARCHAR(MAX), COLUMN_4 INT, COLUMN_5 NVARCHAR(MAX), COLUMN_6 NVARCHAR(MAX), COLUMN_7 NVARCHAR(MAX))
CREATE TABLE #MY_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400), COLUMN_4 NVARCHAR(MAX))
CREATE TABLE #MY_SUB_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400))

CREATE TABLE #2_MY_SUB_TABLE(COLUMN_1 int, COLUMN_2 INT, COLUMN_3 NVARCHAR(MAX), COLUMN_4 INT, COLUMN_5 NVARCHAR(MAX), COLUMN_6 NVARCHAR(MAX), COLUMN_7 NVARCHAR(MAX))
CREATE TABLE #2_MY_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400), COLUMN_4 NVARCHAR(MAX))
CREATE TABLE #2_MY_SUB_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400))

CREATE TABLE #3_MY_SUB_TABLE(COLUMN_1 int, COLUMN_2 INT, COLUMN_3 NVARCHAR(MAX), COLUMN_4 INT, COLUMN_5 NVARCHAR(MAX), COLUMN_6 NVARCHAR(MAX), COLUMN_7 NVARCHAR(MAX))
CREATE TABLE #3_MY_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400), COLUMN_4 NVARCHAR(MAX))
CREATE TABLE #3_MY_SUB_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400))

CREATE TABLE #4_MY_SUB_TABLE(COLUMN_1 int, COLUMN_2 INT, COLUMN_3 NVARCHAR(MAX), COLUMN_4 INT, COLUMN_5 NVARCHAR(MAX), COLUMN_6 NVARCHAR(MAX), COLUMN_7 NVARCHAR(MAX))
CREATE TABLE #4_MY_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400), COLUMN_4 NVARCHAR(MAX))
CREATE TABLE #4_MY_SUB_SUB_SUB_TABLE(COLUMN_1 NVARCHAR(100), COLUMN_2 NVARCHAR(100), COLUMN_3 NVARCHAR(400))



EXEC CONVERT_JSON_OBJECT_TO_SQL_TABLE_3
										'#MY_ROOT_TABLE,
										 #MY_SUB_TABLE,#MY_SUB_SUB_TABLE,#MY_SUB_SUB_SUB_TABLE,
										 |,
										 #2_MY_SUB_TABLE,#2_MY_SUB_SUB_TABLE,#2_MY_SUB_SUB_SUB_TABLE,
										 |,
										 #3_MY_SUB_TABLE,#3_MY_SUB_SUB_TABLE,#3_MY_SUB_SUB_SUB_TABLE,
										 |,
										 #4_MY_SUB_TABLE,#4_MY_SUB_SUB_TABLE,#4_MY_SUB_SUB_SUB_TABLE
										',
										'[{
	"property_one": "1",
	"property_two": "o1_A",

	"complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"property_three": "3",
	"property_four": "4",
	"property_five": "5",
	
	"2_complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},
	
	"complex_3_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"complex_subObject_4_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	}
},{
	"property_one": "1",
	"property_two": "o1_A",

	"complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"property_three": "3",
	"property_four": "4",
	"property_five": "5",
	
	"2_complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},
	
	"complex_3_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"complex_subObject_4_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	}
},{
	"property_one": "1",
	"property_two": "o1_A",

	"complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",

			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
						"property_three": "a+b",
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"property_three": "3",
	"property_four": "4",
	"property_five": "5",
	
	"2_complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},
	
	"complex_3_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"complex_subObject_4_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	}
},{
	"property_one": "1",
	"property_two": "o1_A",

	"complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"property_three": "3",
	"property_four": "4",
	"property_five": "5",
	
	"2_complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},
	
	"complex_3_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"complex_subObject_4_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	}
},{
	"property_one": "1",
	"property_two": "o1_A",

	"complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"property_three": "3",
	"property_four": "4",
	"property_five": "5",
	
	"2_complex_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},
	
	"complex_3_subObject_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	},

	"complex_subObject_4_level_one": {
		"property_one": "11",
		"property_two": "111",
		"property_three": "THIS",
		"property_four": "1001",
		"complex_subObject_level_two": {
			"property_one": "a",
			"property_two": "b",
			"property_three": "a+b",
			"complex_subObject_level_three": {
				"property_one": "sss_1",
				"property_two": "sss_2",
				"property_three": "sss_3"
			},
			"property_four": "a+b+1"
		},
		"property_five": "#",
		"property_six": "$",
		"property_seven": "*"
	}
}]'


/*
SELECT * FROM #MY_ROOT_TABLE
SELECT * FROM #MY_SUB_TABLE
SELECT * FROM #MY_SUB_SUB_TABLE
SELECT * FROM #MY_SUB_SUB_SUB_TABLE

SELECT * FROM #2_MY_SUB_TABLE
SELECT * FROM #2_MY_SUB_SUB_TABLE
SELECT * FROM #2_MY_SUB_SUB_SUB_TABLE

SELECT * FROM #3_MY_SUB_TABLE
SELECT * FROM #3_MY_SUB_SUB_TABLE
SELECT * FROM #3_MY_SUB_SUB_SUB_TABLE

SELECT * FROM #4_MY_SUB_TABLE
SELECT * FROM #4_MY_SUB_SUB_TABLE
SELECT * FROM #4_MY_SUB_SUB_SUB_TABLE
*/

SELECT
	   MT.COLUMN_1, MT.COLUMN_2, MT.COLUMN_3, MT.COLUMN_4, MT.COLUMN_5, '@',

	   MST.COLUMN_1, MST.COLUMN_2, MST.COLUMN_3, MST.COLUMN_4, MST.COLUMN_5, MST.COLUMN_6, MST.COLUMN_7, '@@',
	   MSST.COLUMN_1, MSST.COLUMN_2, MSST.COLUMN_3, MSST.COLUMN_4, '@@@',
	   MSSST.COLUMN_1, MSSST.COLUMN_2, MSSST.COLUMN_3,

	   '======================= 2 -> ========================',

	   MST_2.COLUMN_1, MST_2.COLUMN_2, MST_2.COLUMN_3, MST_2.COLUMN_4, MST_2.COLUMN_5, MST_2.COLUMN_6, MST_2.COLUMN_7, '@@',
	   MSST_2.COLUMN_1, MSST_2.COLUMN_2, MSST_2.COLUMN_3, MSST_2.COLUMN_4, 
	   '@@@',
	   MSSST_2.COLUMN_1, MSSST_2.COLUMN_2, MSSST_2.COLUMN_3,
	   
	   '======================= 3 -> ========================',

	   MST_3.COLUMN_1, MST_3.COLUMN_2, MST_3.COLUMN_3, MST_3.COLUMN_4, MST_3.COLUMN_5, MST_3.COLUMN_6, MST_3.COLUMN_7, '@@',
	   MSST_3.COLUMN_1, MSST_3.COLUMN_2, MSST_3.COLUMN_3, MSST_3.COLUMN_4, '@@@',
	   MSSST_3.COLUMN_1, MSSST_3.COLUMN_2, MSSST_3.COLUMN_3,
	   
	   '======================= 4 -> ========================',

	   MST_4.COLUMN_1, MST_4.COLUMN_2, MST_4.COLUMN_3, MST_4.COLUMN_4, MST_4.COLUMN_5, MST_4.COLUMN_6, MST_4.COLUMN_7, '@@',
	   MSST_4.COLUMN_1, MSST_4.COLUMN_2, MSST_4.COLUMN_3, MSST_4.COLUMN_4,
	   '@@@',
	   MSSST_4.COLUMN_1, MSSST_4.COLUMN_2, MSSST_4.COLUMN_3	   	   	    
FROM #MY_ROOT_TABLE AS MT

JOIN #MY_SUB_TABLE AS MST ON MST._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #MY_SUB_SUB_TABLE AS MSST ON MSST._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #MY_SUB_SUB_SUB_TABLE AS MSSST ON MSSST._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_

JOIN #2_MY_SUB_TABLE AS MST_2 ON MST_2._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #2_MY_SUB_SUB_TABLE AS MSST_2 ON MSST_2._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #2_MY_SUB_SUB_SUB_TABLE AS MSSST_2 ON MSSST_2._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_

JOIN #3_MY_SUB_TABLE AS MST_3 ON MST_3._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #3_MY_SUB_SUB_TABLE AS MSST_3 ON MSST_3._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #3_MY_SUB_SUB_SUB_TABLE AS MSSST_3 ON MSSST_3._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_

JOIN #4_MY_SUB_TABLE AS MST_4 ON MST_4._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #4_MY_SUB_SUB_TABLE AS MSST_4 ON MSST_4._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
JOIN #4_MY_SUB_SUB_SUB_TABLE AS MSSST_4 ON MSSST_4._TABLE_INTERNAL_PK_ = MT._TABLE_INTERNAL_PK_
