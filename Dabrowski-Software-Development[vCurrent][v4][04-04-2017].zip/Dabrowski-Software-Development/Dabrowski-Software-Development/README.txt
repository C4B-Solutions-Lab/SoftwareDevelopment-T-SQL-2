==========================================================================================================================================================================================
THIS MANUAL REFERS TO 
					  CONVERT_SQL_TABLE_TO_JSON_OBJECT_4_P [v4]
																VERSION OF SQL2JSON
==========================================================================================================================================================================================

==========================================================================================================================================================================================
 AUTOMATIC INSTALLATION		||
 AUTOMATIC UNINSTALLATION	||

 IN ORDER TO USE [runControlPanelMgr.bat] PROVIDED IN THE [SolutionNavigator] SOLUTION FOLDER,
 PLEASE GO TO [SolutionNavigator]/[runControlPanelMgrInfo.txt] FILE FOR MORE DETAILS ON WHAT OPTIONS TO USE.
 PLEASE VISIT [CONTROL PANEL v1] SECTION.


 SSMS [runControlPanelMgr.bat] integration:

	Please refer to JSON2SQL SOLUTION'S README.TXT file for there explained installation phase, which is exactly the same.

==========================================================================================================================================================================================


==========================================================================================================================================================================================


==========================================================================================================================================================================================
 MANUAL INSTALLATION		||
							||

	1. RUN [T-SQL_UTILITY_FUNCTIONS_INSTALL.sql]

	2. RUN [SQL2JSON_T-SQL_UTILITY_PROCEDURES_INSTALL.sql]

	3. RUN [CONVERT_SQL_TABLE_TO_JSON_OBJECT_4_P [v4].sql]



 MANUAL UNINSTALLATION		||
							||

	1. RUN [T-SQL_UTILITY_FUNCTIONS_UNINSTALL.sql]

	2. RUN [SQL2JSON_T-SQL_UTILITY_PROCEDURES_UNINSTALL.sql]
==========================================================================================================================================================================================


==========================================================================================================================================================================================


==========================================================================================================================================================================================
 TESTING OF VERSIONS		||
							||

	===========================================================
	v1.8.0 [ CONVERT_SQL_TABLE_TO_JSON_OBJECT_4_P [v4] ]
	===========================================================

	For instructions please go to:  ..\TESTS\README.txt
	

========================================================================================================================================================================================







==================									   ===================================                                       ===============================                   =====
                     =====================                       =============================                           ====================                             ==============






========================================================================================================================================================================================
 Input parameters explanation [version v1.8.0]
========================================================================================================================================================================================
 ______________________________________________________________________________________________________________________________________________________________________________________
|																																													   |
|																																													   | 
|																																													   |
|																																													   |
|	::[ @P_JSON_COLLECTION_OBJECT_LAYOUT ]::																																		   |
|		FIRST INPUT PARAMETER REFLECTS SINGLE MAIN JSON OBJECT, i.e. in the provided samples such main object consists of max. 3 complex properties.								   |
|		Each complex property is separated from another by using |																													   |
|																																													   |
|										'MY_ROOT_TABLE, -- this table reflects properties of main object																			   |
|										 MY_SUB_TABLE_1_1,MY_SUB_TABLE_1_2,MY_SUB_TABLE_1_3, -- these tables reflect properties of first complex object under main object		       |
|										  (MY_SUB_TABLE_1_1 -> nesting level 2) (MY_SUB_TABLE_1_2 -> nesting level 3) (MY_SUB_TABLE_1_4 -> nesting level 4)                            |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 MY_SUB_TABLE_2_1,MY_SUB_TABLE_2_2,MY_SUB_TABLE_2_3, --these tables reflect properties of second complex object under main object              |
|										  (MY_SUB_TABLE_2_1 -> nesting level 2) (MY_SUB_TABLE_2_2 -> nesting level 3) (MY_SUB_TABLE_2_3 -> nesting level 4)                            |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 MY_SUB_TABLE_3_1,MY_SUB_TABLE_3_2,MY_SUB_TABLE_3_3, --these tables reflect properties of third complex object under main object	           |
|										  (MY_SUB_TABLE_3_1 -> nesting level 2) (MY_SUB_TABLE_3_2 -> nesting level 3) (MY_SUB_TABLE_3_3 -> nesting level 4)                            |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   | 
|										 MY_SUB_TABLE_4_1,MY_SUB_TABLE_4_2,MY_SUB_TABLE_4_3 --these tables reflect properties of fourth complex object under main object               |
|										  (MY_SUB_TABLE_4_1 -> nesting level 2) (MY_SUB_TABLE_4_2 -> nesting level 3) (MY_SUB_TABLE_4_3 -> nesting level 4)                            |
|																																													   |
|	::[ @P_JSON_OUTPUT ]::																																							   |
|		SECOND INPUT/OUTPUT PARAMETER HOLDS RETURNED JSON OBJECT																													   |
|																																													   |
|______________________________________________________________________________________________________________________________________________________________________________________|