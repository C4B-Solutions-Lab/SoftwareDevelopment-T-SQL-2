﻿To test this algorithm follow below steps:

 1. Run one of the tests of Json2Sql (1.A, 1.A, 1.C, 1.D, 2.A, 2.B) to fill in required tables.

 2. Copy JSON table collection layout provided as a first parameter of CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P for the above test.
 
 3. Run CONVERT_SQL_TABLE_TO_JSON_OBJECT_4_P feeding in this layout into the first parameter of this procedure.