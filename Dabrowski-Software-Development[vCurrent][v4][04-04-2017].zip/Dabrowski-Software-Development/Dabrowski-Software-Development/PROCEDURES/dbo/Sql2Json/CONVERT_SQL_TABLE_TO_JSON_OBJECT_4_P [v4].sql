﻿-- ======================================================================================================================================================================================================
-- author:					Łukasz Dąbrowski
-- project:					DABROWSKI SOFTWARE DEVELOPMENT
--
-- www:						https://dabrowski-software-development.github.io/, coming soon https://dabrowski-software-development.org
--
-- creation date:			2017-02-08
--
-- modification date:		2017-03-19, 2017-03-16, 2017-03-15, 2017-02-21
--
-- description:				Returns data from a set of tables in the form of JSON format. Support for SQL SERVER versions prior to SQL SERVER 2016.
--							Supported data types are:
--									BIT, TINYINT, SMALLINT, INT, BIGINT, NUMERIC, DECIMAL, FLOAT, REAL, SMALLMONEY, MONEY,
--									CHAR, NCHAR, VARCHAR, NVARCHAR,
--									BINARY, VARBINARY,
--									UNIQUEIDENTIFIER,
--									TIMESTAMP, SMALLDATETIME, DATETIME, DATETIME2, DATE, TIME, DATETIMEOFFSET
--
--							In order to use XML it has to be passed as (N)VARCHAR, i.e. underlying table has to have such XML stored as (N)VARCHAR column.
--
--							This version is the replacement of the previous one,
--							i.e. CONVERT_QUERY_RESULT_TO_JSON_FORMAT (which is excluded from this solution) and serves exactly the reversed functionality to the CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P.
--							Both procedures, CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P and CONVERT_SQL_TABLE_TO_JSON_OBJECT_4_P share the same first input parameter,
--							which idicates the layout of the underlying tables.
--
--							One of the first steps procedure performs is the validation of underlying tables. Each and every table has to have primary key and it has to be of type INT.
--							Otherwise validation will fail and procedure will terminate its execution.
--												
--							This procedure depends on the following procedures, which are included in this solution in the file called [SQL2JSON_T-SQL_UTILITY_PROCEDURES_INSTALL.sql]
--
--												dbo.SQL2JSON_1_VALIDATE_JSON_COLLECTION_OBJECT_LAYOUT___fill_in___JSON_OBJECT_LAYOUT_TABLE_COLLECTION
--												dbo.SQL2JSON_2_CREATE_MAIN_JSON_OBJECT_TEMPLATE___REPLACE_TEMPLATE___AND___JOIN_TABLE_STATEMENTS
--												dbo.SQL2JSON_4_FETCH_GENERATED_TEMPLATES
--												dbo.SQL2JSON_5_VALIDATE_MAIN_JSON_OBJECT_TEMPLATE
--												dbo.SQL2JSON_6_MAIN_JSON_OBJECT___fill_in___TEMPLATE
--
--
-- WARNING:					N/A
--					
-- version:			1.8.0
--
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
--
-- feedback:		lukkasz.dabrowski@gmail.com
-- =======================================================================================================================================================================================================

/* SET CURRENT DATABASE CONTEXT */
 USE $(UseDatabase)
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE CONVERT_SQL_TABLE_TO_JSON_OBJECT_4_P
(
 @P_JSON_COLLECTION_OBJECT_LAYOUT AS NVARCHAR(MAX),
 @P_JSON_OUTPUT AS NVARCHAR(MAX) OUTPUT
)
AS
BEGIN

	SET NOCOUNT ON
	SET ANSI_NULLS ON


	/* SET UP INITIAL VARIABLES */
	DECLARE @DOLLAR_SIGN AS CHAR = '$'
	DECLARE
		@ERROR_TEMPLATE AS NVARCHAR(MAX) = N'',
		@ERROR_MESSAGE AS NVARCHAR(MAX) = N'',
		@SEPARATOR AS CHAR = '|',
		@OPENING_CURLY_BRACKET AS NCHAR = N'{',
		@CLOSING_CURLY_BRACKET AS NCHAR = N'}',
		@MISSING_LEVEL_OBJECT AS CHAR(26) = '___MISSING_LEVEL_OBJECT___',
		@EMPTY_STRING AS VARCHAR = '',
		@N_EMPTY_STRING AS NVARCHAR = N'',
		@QUOTATION_MARK AS CHAR = '"',
		@_3_UNDERSCORES AS CHAR(3) = '___',
		@SPACE__COLON__SPACE__QUOTATION_MARK__DOLLAR_SIGN AS CHAR(5) = ' : "' + @DOLLAR_SIGN,
		@TABULATOR AS CHAR = CHAR(9),
		@ENTER AS CHAR(2) = CHAR(13)+CHAR(10),
		@COMMA AS CHAR = CHAR(44),
		@RETURN_RESULT AS BIT,
		@REPLACE_STATEMENT AS NVARCHAR(MAX) = N'',
		@FROM_JOIN_STATEMENT AS NVARCHAR(MAX) = N'',
		@OUTPUT_STORAGE_UPDATE_STATEMENT AS NCHAR(44) = N''


	/* 
	  CREATE GLOBAL BUFFERS TO STORE 
		1.	PARTIAL MAIN JSON OBJECT TEMPLATE
		2.	PARTIAL JSON COLLECTION OBJECT LAYOUT TABLES' COLUMNS REPLACE TEMPLATE
		3.	PARTIAL JSON COLLECTION OBJECT LAYOUT TABLES' JOIN STATEMENT
	*/
	CREATE TABLE #JSON_OBJECT_TEMPLATE_BUFFER
	(
	  ID INT IDENTITY NOT NULL PRIMARY KEY,
	  PARTIAL_TEMPLATE NVARCHAR(MAX)
	)

	CREATE TABLE #REPLACE_TEMPLATE_STATEMENT_BUFFER
	(
	  ID INT IDENTITY NOT NULL PRIMARY KEY,
	  PARTIAL_REPLACE_TEMPLATE_STATEMENT NVARCHAR(MAX)
	)

	CREATE TABLE #JOIN_STATEMENT_BUFFER
	(
	  ID INT IDENTITY NOT NULL PRIMARY KEY,
	  PARTIAL_JOIN_STATEMENT NVARCHAR(MAX)
	)



	/* [ CORE PROCESSING - PART 1 ] VALIDATE TABLES */
	DECLARE
		@VALIDATION_INDEX_START AS INT = 1,
		@VALIDATION_INDEX_END AS INT = -1,
		@TABLE_NAME AS NVARCHAR(MAX) = @N_EMPTY_STRING

	/* CREATE TEMPORARY TABLE TO STORE JSON OBJECT LAYOUT */
	CREATE TABLE #JSON_OBJECT_LAYOUT_TABLE_COLLECTION
	(
		ID INT NOT NULL,
		TABLE_NAME NVARCHAR(MAX),
		PK_COLUMN NVARCHAR(128)
	)


	/* EXECUTE VALIDATION */
	EXECUTE dbo.SQL2JSON_1_VALIDATE_JSON_COLLECTION_OBJECT_LAYOUT___fill_in___JSON_OBJECT_LAYOUT_TABLE_COLLECTION -- (ID, TABLE_NAME)
												@P_JSON_COLLECTION_OBJECT_LAYOUT,
												@COMMA,
												@N_EMPTY_STRING,
												@TABLE_NAME,
												@SEPARATOR,
												@MISSING_LEVEL_OBJECT,
												@ERROR_TEMPLATE,
												@VALIDATION_INDEX_END OUTPUT,
												@RETURN_RESULT OUTPUT

	IF @RETURN_RESULT = 0
	  RETURN
    


	/* [ CORE PROCESSING - PART 2 ] CREATE TEMPLATES */
	DECLARE
		@JSON_OBJECT_LAYOUT_TABLE_COLLECTION_JOIN_STATEMENT AS NVARCHAR(MAX) = @N_EMPTY_STRING,
		@CLOSE_MAIN_JSON_OBJECT AS BIT = 0,

		@JSON_OBJECT_LAYOUT_TABLE_COLLECTION___INDEX_START AS INT = 1,
		@JSON_OBJECT_LAYOUT_TABLE_COLLECTION___INDEX_STOP AS INT = -1


	/* EXECUTE TEMPLATE GENERATION */
	EXECUTE dbo.SQL2JSON_2_CREATE_MAIN_JSON_OBJECT_TEMPLATE___REPLACE_TEMPLATE___AND___JOIN_TABLE_STATEMENTS
																											@TABULATOR,
																											@TABLE_NAME,
																											@CLOSE_MAIN_JSON_OBJECT,
																											@SEPARATOR,
																											@ENTER,
																											@COMMA,
																											@_3_UNDERSCORES,
																											@SPACE__COLON__SPACE__QUOTATION_MARK__DOLLAR_SIGN,
																											@QUOTATION_MARK,
																											@DOLLAR_SIGN,
																											@N_EMPTY_STRING,
																											@OPENING_CURLY_BRACKET,
																											@CLOSING_CURLY_BRACKET,
																											@MISSING_LEVEL_OBJECT,
																											@JSON_OBJECT_LAYOUT_TABLE_COLLECTION___INDEX_START,
																											@JSON_OBJECT_LAYOUT_TABLE_COLLECTION___INDEX_STOP OUTPUT,
																											@JSON_OBJECT_LAYOUT_TABLE_COLLECTION_JOIN_STATEMENT OUTPUT,
																											@OUTPUT_STORAGE_UPDATE_STATEMENT OUTPUT



	/* [ CORE PROCESSING - PART 3 ] FETCH GENERATED TEMPLATES INTO TEMPORARY VARIABLES */

	EXECUTE dbo.SQL2JSON_4_FETCH_GENERATED_TEMPLATES
											@N_EMPTY_STRING,
											@P_JSON_OUTPUT OUTPUT,
											@REPLACE_STATEMENT OUTPUT,
											@FROM_JOIN_STATEMENT OUTPUT



	/* [ CORE PROCESSING - PART 4 ] VALIDATE MAIN JSON TEMPLATE */
	EXECUTE dbo.SQL2JSON_5_VALIDATE_MAIN_JSON_OBJECT_TEMPLATE
									@EMPTY_STRING,
									@COMMA,
									@ERROR_TEMPLATE,
									@P_JSON_OUTPUT OUTPUT,
									@RETURN_RESULT OUTPUT

	IF @RETURN_RESULT = 0
	  RETURN



	/* [ CORE PROCESSING - PART 5 ] BIND EACH RECORD OF USER DATA OF LOGICALLY CONNECTED TABLES TO MAIN JSON OBJECT TEMPLATE (DO INITIAL SETUP) */
	SET @TABLE_NAME = @N_EMPTY_STRING

	SELECT
		@TABLE_NAME = JOLTC.TABLE_NAME
	FROM #JSON_OBJECT_LAYOUT_TABLE_COLLECTION AS JOLTC
	WHERE JOLTC.ID = 1


	/* CREATE OUTPUT STORAGE */
	CREATE TABLE #USER_DATA_TO_JSON_OBJECT_STORAGE
	(
		ID INT IDENTITY NOT NULL PRIMARY KEY NONCLUSTERED,
		JSON_OBJECT NVARCHAR(MAX)
	)

	/* GENERATE REAL MAIN JSON OBJECT COLLECTION FROM TEPLATE */
	EXECUTE dbo.SQL2JSON_6_MAIN_JSON_OBJECT___fill_in___TEMPLATE
																	@TABLE_NAME,
																	@N_EMPTY_STRING,
																	@P_JSON_OUTPUT,
																	@OUTPUT_STORAGE_UPDATE_STATEMENT,
																	@REPLACE_STATEMENT,
																	@FROM_JOIN_STATEMENT



	/* [ CORE PROCESSING - PART 6 ] PREPARE FINAL JSON OUTPUT */
	SET @P_JSON_OUTPUT = CAST(@EMPTY_STRING AS NVARCHAR(MAX))
	DECLARE
		@OPEN_SQUARE_BRACKET AS CHAR = '[',
		@CLOSE_SQUARE_BRACKET AS CHAR = ']'


	;WITH OUTPUT_JSON AS (
		SELECT
			ANCHOR.ID AS ID, ANCHOR.JSON_OBJECT AS OUTPUT_JSON_OBJECT
		FROM #USER_DATA_TO_JSON_OBJECT_STORAGE AS ANCHOR
		WHERE ANCHOR.ID = 1

		UNION ALL

		SELECT
			BASE.ID AS ID, OJ.OUTPUT_JSON_OBJECT + @COMMA + BASE.JSON_OBJECT AS OUTPUT_JSON_OBJECT
		FROM OUTPUT_JSON AS OJ
		JOIN #USER_DATA_TO_JSON_OBJECT_STORAGE AS BASE ON BASE.ID = OJ.ID + 1
	)
	SELECT
		@P_JSON_OUTPUT = OJ.OUTPUT_JSON_OBJECT
	FROM OUTPUT_JSON AS OJ
	OPTION (MAXRECURSION 0)


	/* RETURN JSON */
	SET @P_JSON_OUTPUT = @OPEN_SQUARE_BRACKET + @P_JSON_OUTPUT + @CLOSE_SQUARE_BRACKET

END
GO
